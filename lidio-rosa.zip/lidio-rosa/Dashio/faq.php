<?php
session_start();
if (!$_SESSION["auth_user"]) {
    header('Location: ../');
}

$placa = $_SESSION["user_id"];

?>

<!DOCTYPE php>
<php lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>LidioDash</title>

  <!-- Favicons -->
  <link href="../res/img/favicon.png" rel="icon">
  <link href="../res/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../res/css/style.css" rel="stylesheet">
  <link href="../res/css/style-responsive.css" rel="stylesheet">

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
   <!--header start-->
   <header class="header black-bg">
    <div class="sidebar-toggle-box">
      <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
    </div>
    <!--logo start-->
    <a href="index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
    <!--logo end-->
    <div class="nav notify-row" id="top_menu">
      <!--  notification start -->
      <ul class="nav top-menu">

        <!-- notification dropdown end -->
      </ul>
      <!--  notification end -->
    </div>
    
    <div class="top-menu">
      <ul class="nav pull-right top-menu">
        <li><a class="logout" href="../index.php">Sair</a></li>
      </ul>
    </div>
  
  </header>
  <!--header end-->
  <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
  <!--sidebar start-->
  <aside>
    <div id="sidebar" class="nav-collapse ">
      <!-- sidebar menu start-->
      <ul class="sidebar-menu" id="nav-accordion">
        <p class="centered"><img src="<?php echo "../res/img/users_img/".$_SESSION["foto"] ?>" class="img-circle"
            width="80"></p>
        <h5 class="centered"><?php echo $_SESSION["nome"] ?></h5>
  
        <li class="sub-menu">
          <a href="index.php">
            <i class="fa fa-desktop"></i>
            <span>Meu Serviço</span>
          </a>
        </li>
        <li class="sub-menu">
          <a href="historico.php">
            <i class="fa fa-history"></i>
            <span>Histórico</span>
          </a>
        </li>
        <li class="sub-menu">
          <a href="meus-dados">
            <i class="fa fa-user"></i>
            <span>Meus dados</span>
          </a>
        </li>
        <li class="sub-menu">
          <a class="active" href="faq.php">
            <i class="fa fa-question" aria-hidden="true"></i>
            <span>FAQ</span>
          </a>
        </li>
      </ul>
      <!-- sidebar menu end-->
    </div>
  </aside>
  <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <div class="row mt mb">
          <div class="col-lg-12">
            <h3><i class="fa fa-angle-right"></i> Central de Ajuda</h3>
            <br>
            
          </div>
          <!--  /col-lg-12 -->
        </div>
        <!-- /row -->
        <div class="row content-panel">
          <h2 class="centered">Como usar a LidioDash?</h2>
          <div class="col-md-10 col-md-offset-1 mt mb">
            <div class="accordion" id="accordion2">
              <div class="accordion-group">
                <div class="accordion-heading">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="faq.php#collapseOne">
                    <em class="glyphicon glyphicon-chevron-right icon-fixed-width"></em> Como acompanhar serviço em tempo real?
                    </a>
                </div>
                <div id="collapseOne" class="accordion-body collapse in">
                  <div class="accordion-inner">
                    <p> Na página de "Meu Serviço" você encontrará uma listagem de todos os serviços que já realizou, 
                      para acompanhar seu serviço em tempo real, apenas clique no botão azul representado por um olho após a coluna de "Status". </p>
                  </div>
                </div>
              </div>
              <div class="accordion-group">
                <div class="accordion-heading">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="faq.php#collapseTwo">
                    <em class="glyphicon glyphicon-chevron-right icon-fixed-width"></em> Para que serve a linha do tempo?
                    </a>
                </div>
                <div id="collapseTwo" class="accordion-body collapse">
                  <div class="accordion-inner">
                    <p>Após clicar para visualizar seu serviço em tempo real, todas as informações serão 
                      transmitidas através de uma linha do tempo, onde constará quais procedimentos estão sendo 
                      realizados na manutenção, suas respectivas datas e horários. Assim que a manutenção estiver 
                      como finalizado ou pronto para entrega, será informado na linha do tempo para que possa se dirigir ao local. </p>
                  </div>
                </div>
              </div>
              <div class="accordion-group">
                <div class="accordion-heading">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="faq.php#collapseThree">
                    <em class="glyphicon glyphicon-chevron-right icon-fixed-width"></em> Quais dados pessoais posso alterar?
                    </a>
                </div>
                <div id="collapseThree" class="accordion-body collapse">
                  <div class="accordion-inner">
                    <p>Para alterar seus dados pessoais, você deve entrar em contato com os administradores. Você pode contatá-los através da página "Fale Conosco" 
                      presente no site ou ligando diretamente para a loja.
                      Na página "Meus Dados" você poderá alterar apenas a senha cadastrada inicialmente pelos administradores</p>
                  </div>
                </div>
              </div>
              <div class="accordion-group">
                <div class="accordion-heading">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="faq.php#collapseFour">
                    <em class="glyphicon glyphicon-chevron-right icon-fixed-width"></em> Como ver meu histórico antigo de serviços finalizados?
                    </a>
                </div>
                <div id="collapseFour" class="accordion-body collapse">
                  <div class="accordion-inner">
                    <p>Ao finalizar seus serviços, todos os seus históricos ficarão salvos na página "Meu Serviço". 
                      As colunas na lista de serviços que identificam a quilometragem e data de chegada, representam os seus históricos antigos. Para acessá-los, apenas clique no botão azul representado por um X após a coluna de "Status".</p>
                  </div>
                </div>
              </div>
              
            </div>
            <!-- end accordion -->
          </div>
          <!-- col-md-10 -->
        </div>
        <!--  /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
        </p>
        <div class="credits">
         
         Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
        </div>
        <a href="index.php#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
        
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../res/lib/jquery/jquery.min.js"></script>
  <script src="../res/lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../res/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../res/lib/jquery.scrollTo.min.js"></script>
  <script src="../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="../res/lib/common-scripts.js"></script>
  <!--script for this page-->

</body>

</php>
