<?php
    session_start();
    if (!$_SESSION["auth_user"]) {
        header('Location: ../login');
    }

    if(empty($_GET["pagina"])) {
        $_GET["pagina"] = 1;
    }
    $pagina = $_GET["pagina"];

    $total_reg = 25;

    include_once '../php/init.php';
    
    $PDO = db_connect();
    $sql = 'SELECT m.id, s.etapa, c.proprietario, m.quilometragem, c.placa, m.titulo_manutencao, m.descricao, DATE_FORMAT(data_inicio, "%d\.%m\.%Y") FROM manutencoes AS m JOIN carros AS c ON c.placa = m.placa AND c.placa = :placa JOIN status AS s ON s.id_manutencao = m.id ORDER BY data_inicio DESC, etapa DESC';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $_SESSION["user_id"]);
    $stmt -> execute();
    
    $PDO2 = db_connect();
    $sql2 = 'SELECT * FROM carros WHERE placa = :placa';
    $stmt2 = $PDO2 -> prepare($sql2);
    $stmt2 -> bindParam(':placa', $_SESSION["user_id"]);
    $stmt2 -> execute();

    $user_dados = $stmt2 -> fetch();

    $_SESSION["nome"] = $user_dados["proprietario"];
    $_SESSION["foto"] = $user_dados["foto_user"];

    $dados = $stmt -> fetchAll();

    $dados_final = array();
    $id = array();

    $qtd = count($dados);
 
    for($i = 0; $i < $qtd; $i++) {
        if(empty($dados_final)) {
            array_push($dados_final, $dados[$i]);
            array_push($id, $dados[$i]["id"]);
        } else if(!in_array($dados[$i]["id"], $id)) {
            array_push($dados_final, $dados[$i]);
            array_push($id, $dados[$i]["id"]);
        }
    }

    $qtd = count($dados_final);

    $ultima_etapa = 8;

    $tp = number_format(ceil($qtd / $total_reg));

    if($tp == 0) {
        $tp = 1;
    }

    $qtd_da_pagina = 0;

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../res/img/favicon.png" rel="icon">
    <link href="../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../res/css/style.css" rel="stylesheet">
    <link href="../res/css/my-style.css" rel="stylesheet">
    <link href="../res/css/style-responsive.css" rel="stylesheet">
    <script src="../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="<?php echo "../res/img/users_img/".$_SESSION["foto"] ?>"
                            class="img-circle" width="80"></p>
                    <h5 class="centered"><?php echo $_SESSION["nome"] ?></h5>

                    <li class="sub-menu">
                        <a class="active" href="index.php">
                            <i class="fa fa-desktop"></i>
                            <span>Meu Serviço</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="historico.php">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="faq.php">
                            <i class="fa fa-question" aria-hidden="true"></i>
                            <span>FAQ</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->

        <!-- Content Wrapper. Contains page content -->
        <section id="main-content">
            <section class="wrapper-1 ">

                <div class="col-lg-12">
                    <!-- Content Header (Page header) -->
                    <section class="content-header">
                        <div class="container-fluid">
                            <div class="row mb-2">
                                <div class="col-sm-6">
                                    <h1>Linha do Tempo</h1>
                                </div>

                            </div>
                        </div><!-- /.container-fluid -->
                    </section>

                    <!-- Main content -->
                    <section class="content">
                        <div class="container-fluid">

                            <!-- Timelime example  -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="content-panel">
                                        <table class="table table-striped table-advance table-hover">
                                            <h4><i class="fa fa-angle-right"></i> Manutenções</h4>
                                            <span style="margin-left: 10px; font-size: 15px;">Página <?php echo($pagina." de ".$tp)?> <small id="registros-qtd">(25 registros)</small></span>
                                            <hr>
                                            <thead>
                                                <tr>
                                                    <th><i class="fa fa-tachometer"></i> Quilometragem</th>
                                                    <th class="hidden-phone"><i class="fa fa-question-circle"></i>
                                                        Descrição</th>
                                                    <th><i class="fa fa-bookmark"></i> Placa</th>
                                                    <th><i class="fa fa-calendar-check-o"></i> Data de chegada</th>
                                                    <th><i class=" fa fa-edit"></i> Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                  for ($i = ($pagina-1)*$total_reg; $i < $qtd && $i < $total_reg*$pagina; $i++) {
                                                      $qtd_da_pagina++;
                                                      $link = "timeline.php?id=".$dados_final[$i]["id"];
                                                      $data = $dados_final[$i]["DATE_FORMAT(data_inicio, \"%d\.%m\.%Y\")"];
                                                      $km = implode(".", array_map("strrev", array_reverse(str_split(strrev(implode("", explode(".", $dados_final[$i]["quilometragem"]))), 3))));
                                                ?>
                                                <tr>
                                                    <td><?php echo $km ?> km</td>
                                                    <td class="hidden-phone"><?php echo $dados_final[$i]["titulo_manutencao"]?></td>
                                                    <td><?php echo $dados_final[$i]["placa"]?></td>
                                                    <td><?php echo $data?></td>
                                                    <?php if($dados_final[$i]["etapa"] < $ultima_etapa) { ?>
                                                    <td><span class="label label-warning label-mini">Andamento</span>
                                                    </td>
                                                    <?php }else { ?>
                                                    <td><span class="label label-success label-mini">Feito</span></td>
                                                    <?php } ?>

                                                    <td>
                                                        <form action="<?php echo $link ?>" method="POST">
                                                            <button class="btn btn-primary btn-xs"
                                                                title="Clique para visualizar" name="submit"
                                                                value="Enviar"><i class="fa fa-eye"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php } ?>

                                            </tbody>
                                        </table>
                                        <div style="display: flex; justify-content: center;">
                                            <?php if(($pagina) > 3) {?>
                                                <a href="index.php?pagina=<?php echo(1) ?>">Início</a><span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i> <?php echo (($pagina - 12) > 1)?"<i class='fa fa-ellipsis-h' aria-hidden='true'></i>":"" ?></span> 
                                            <?php } ?>
                                            <?php if(($pagina - 12) > 1) {?>
                                                <a href="index.php?pagina=<?php echo($pagina - 12) ?>"><?php echo($pagina - 12) ?></a><span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></span>
                                            <?php } ?>
                                            <?php for ($i=2; $i > 0; $i--) { ?>
                                                <?php if(($pagina - $i) >= 1) {?>
                                                    <a href="index.php?pagina=<?php echo($pagina - $i) ?>" style="margin-right: 5px;"><?php echo($pagina - $i) ?></a>
                                                <?php } ?>
                                            <?php } ?>
                                                <a href="index.php?pagina=<?php echo($pagina) ?>" style="font-weight: bold; text-decoration: underline;"><?php echo($pagina) ?></a>
                                            <?php for ($i=1; $i < 3; $i++) { ?>
                                                <?php if($pagina + $i <= $tp) {?>
                                                    <a href="index.php?pagina=<?php echo($pagina + $i) ?>" style="margin-left: 5px;"><?php echo ($pagina + $i) ?></a>
                                                <?php } ?>
                                            <?php } ?>
                                            <?php if($pagina + 12 < $tp) {?>
                                                <span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></span><a href="index.php?pagina=<?php echo($pagina + 12) ?>"><?php echo($pagina + 12) ?></a>
                                            <?php } ?>
                                            <?php if($pagina < $tp - 2) {?>
                                                <span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i> <?php echo (($pagina + 12) < $tp)?"<i class='fa fa-ellipsis-h' aria-hidden='true'></i>":"" ?></span><a href="index.php?pagina=<?php echo($tp) ?>">Fim</a>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <!-- /.col -->
                                </div>
                            </div>
                            <!-- /.timeline -->

                    </section>
                    <!-- /.content -->
                </div>

                <!-- /.content-wrapper -->
            </section>
        </section>

        <!--footer start-->
        <footer class="site-footer" id="footer-cadastro">
            <div class="text-center">
                <p>
                    &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                </p>
                <div class="credits">

                    Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                </div>
                <a href="timeline-user.php" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->

    </section>

    <!-- jQuery -->
    <script src="../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../res/lib/common-scripts.js"></script>
    <script>
        document.querySelector('#registros-qtd').textContent = "(<?php echo $qtd_da_pagina ?> registros)"
    </script>

</body>

</html>