<?php
    session_start();
    if(!$_SESSION["auth_user"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }
    
    $senha = $_POST["senha"];
    $confirmar_senha = $_POST["confirmar_senha"];

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";

    if(strcmp($senha, $confirmar_senha) == 0) {
        include_once '../../php/init.php';

        $PDO = db_connect();

        $sql = 'UPDATE carros SET senha=:senha WHERE placa=:placa LIMIT 1';
        $stmt = $PDO -> prepare($sql);
        $stmt -> bindParam(':placa', $_POST["placa"]);
        $stmt -> bindParam(':senha', $_POST["senha"]);

        if($stmt -> execute()) {
            $_SESSION["msg"] = "<p style='color: green; text-align: center'>Senha atualizada com sucesso!</p>";
        } else {
            $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível atualizar a senha. Tente novamente.</p>";
        }
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível atualizar a senha. Tente novamente.</p>";
    }

    echo "<script>location.href='./'</script>";