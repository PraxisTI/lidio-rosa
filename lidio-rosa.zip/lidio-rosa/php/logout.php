<?php
    session_start();
    $_SESSION["auth_user"] = false;
    session_unset();
    session_destroy();

    header('Location: ../');