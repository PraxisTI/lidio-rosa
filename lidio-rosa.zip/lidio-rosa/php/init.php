<?php
    define('DB_NAME', 'praxi185_lidiorosa');
    define('DB_HOST', 'localhost');
    define('DB_USER', 'praxi185_lidio');
    define('DB_PASS', '123456');

    // Habilita todas as exibições de erros
    ini_set('display_errors', true);
    error_reporting(E_ALL);
    
    // Horário padrão do Brasil
    date_default_timezone_set('America/Sao_Paulo');

    // Conexão com o banco de dados
    require_once 'connect.php';