<?php
if(!empty($_POST)) {
 
    // EDIT THE 3 LINES BELOW AS REQUIRED
    $email_to = "nathaliamornelas@gmail.com";      // Quem vai receber o e-mail
    $email_subject = "Pedido de Orçamento";        // Assunto
    $email_from = "nathaliamornelas@gmail.com";    // Quem enviou o e-mail
 
    function died($error) {
        // your error code can go here
        echo "Me desculpe, mas encontramos erros no preenchimento do formulário. ";
        echo "Esses são os erros abaixo.<br /><br />";
        echo $error."<br /><br />";
        echo "Por favor, volte e tente novamente! <br /><br />";
        die();
    }
 
 
    // validation expected data exists
    if(!isset($_POST['servico']) ||
        !isset($_POST['nome']) ||
        !isset($_POST['email']) ||
        !isset($_POST['tel']) ||
        !isset($_POST['data']) ||
        !isset($_POST['horario']) ||
        !isset($_POST['mensagem'])) {
        died('Desculpe, mas encontramos erros no preenchimento do formulário.');       
    }
 
     
    $service = $_POST['servico']; // required
    $first_name = $_POST['nome']; // required
    $email = $_POST['email']; // required
    $number = $_POST['tel']; // required
    $date = $_POST['data']; // not required
    $time = $_POST['horario']; // not required
    $comments = $_POST['mensagem']; // required
 
    $error_message = "";
 
    $string_exp = "/^[A-Za-z .'-]+$/";
 
  if(!preg_match($string_exp,$first_name)) {
    $error_message .= 'O nome que preencheu não parece válido.<br />';
  }
 
  if(strlen($comments) < 2) {
    $error_message .= 'A mensagem que preencheu não parece válido.<br />';
  }
 
  if(strlen($error_message) > 0) {
    died($error_message);
  }
 
    $email_message = "Detalhes da mensagem abaixo.\n\n";
 
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
     
    $email_message .= "Serviço: ".clean_string($service)."\n";
    $email_message .= "Nome do Cliente: ".clean_string($first_name)."\n";
    $email_message .= "E-mail: ".clean_string($email)."\n";
    $email_message .= "Telefone: ".clean_string($number)."\n";
    $email_message .= "Data: ".clean_string($date)."\n";
    $email_message .= "Horário: ".clean_string($time)."\n";
    $email_message .= "Mensagem: ".clean_string($comments)."\n";
    
// create email headers
$headers = 'From: [ORÇAMENTO] Lidio Rosa <'.$email_from.">\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
mail($email_to, $email_subject, $email_message, $headers);

echo "<script>alert('Obrigado! Em breve entraremos em contato');window.location.assign('../');</script>";
 
}
?>