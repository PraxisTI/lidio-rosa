<?php
    // Inicia a sessão
    session_start();
    $_SESSION["auth_user"] = false;

    // Inclui configurações do banco
    include_once '../php/init.php';

    // Variáveis enviadas pela formulário
    $placa = strtoupper($_POST["placa"]);
    $senha = $_POST["senha"];
    
    // Busca cadastro no banco de dados
    // Se não encontrar redireciona para página de login
    $PDO = db_connect();
    $sql = 'SELECT placa, senha FROM carros WHERE placa = :placa AND senha = :senha';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $placa);
    $stmt -> bindParam(':senha', $senha);
    if($stmt -> execute()) { // Busca realizada com sucesso
        $dados = $stmt -> fetch();
        if(empty($dados)) { // Nenhum registro no banco de dados
            $_SESSION["msg_auth"] = "<p style='color:#dd2f2c; font-size:13px; text-align:center; transform:translateY(-25px);'>Usuário não encontrado</p>";
            header("Location: index.php");
        } else { // Registro encontrado
            $_SESSION["auth_user"] = true;
            $_SESSION["user_id"] = $placa;
            header("Location: ../Dashio/index.php");
        }
    } else {
        $_SESSION["msg_auth"] = "<p style='color:#dd2f2c; font-size:13px; text-align:center; transform:translateY(-20px);'>Usuário não encontrado</p>";
        header("Location: index.php");
    }

    

