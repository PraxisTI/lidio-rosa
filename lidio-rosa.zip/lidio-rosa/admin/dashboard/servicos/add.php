<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    $servico = $_POST["servico"];
    $preco = str_replace(',', '.', $_POST["preco"]);
    $tempo = str_replace(',', '.', $_POST["tempo"]);
    $categoria = $_POST["categoria"];

    $preco_final = $preco*$tempo;

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'INSERT INTO servicos(servico, preco, tempo, preco_final, categoria) VALUES (:servico, :preco, :tempo, :preco_final, :categoria)';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':servico', $servico);
    $stmt -> bindParam(':preco', $preco);
    $stmt -> bindParam(':tempo', $tempo);
    $stmt -> bindParam(':categoria', $categoria);
    $stmt -> bindParam(':preco_final', $preco_final);
    if($stmt -> execute()) {
        $_SESSION['msg'] = "<p style='color: green; text-align: center'>Serviço cadastrado com sucesso!</p>";
    } else {
        $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível cadastrar o serviço.<br>Tente novamente.</p>";
    }

    header('Location: ./');