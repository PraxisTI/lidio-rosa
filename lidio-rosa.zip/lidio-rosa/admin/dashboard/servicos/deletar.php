<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    if(empty($_POST)) {
        header('Location: ./');
    }

    $id = $_GET["id"];

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'UPDATE servicos SET ativo = false WHERE id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $id);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Serviço excluído com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível excluir o serviço.<br>Tente novamente.</p>";
    }

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";
    echo "<script>location.href='./'</script>";