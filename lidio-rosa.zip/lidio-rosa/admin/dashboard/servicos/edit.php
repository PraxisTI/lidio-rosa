<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    $id = $_POST["id"];
    $servico = $_POST["servico"];
    $preco = str_replace(',', '.', $_POST["preco"]);
    $tempo = str_replace(',', '.', $_POST["tempo"]);
    $categoria = $_POST["categoria"];

    $preco_final = $preco*$tempo;

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'UPDATE servicos SET servico = :servico, preco = :preco, tempo = :tempo, preco_final = :preco_final, categoria = :categoria WHERE id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $id);
    $stmt -> bindParam(':servico', $servico);
    $stmt -> bindParam(':preco', $preco);
    $stmt -> bindParam(':tempo', $tempo);
    $stmt -> bindParam(':preco_final', $preco_final);
    $stmt -> bindParam(':categoria', $categoria);
    if($stmt -> execute()) {
        $_SESSION['msg'] = "<p style='color: green; text-align: center'>Serviço atualizado com sucesso!</p>";
    } else {
        $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível atualizar o serviço.<br>Tente novamente.</p>";
    }

    header('Location: ./');