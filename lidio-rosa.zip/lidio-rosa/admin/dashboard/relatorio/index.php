<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'SELECT m.quilometragem, DATE_FORMAT(m.data_inicio, \'%d/%m/%Y \'), m.qtd_servicos, m.qtd_pecas, c.placa, c.marca, c.modelo, c.proprietario, d.servico_id, d.peca_id, d.quantidade FROM manutencoes AS m JOIN carros AS c ON m.placa = c.placa JOIN manutencoes_detalhes AS d ON d.manutencao_id = m.id WHERE m.id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $_GET["manutencao"]);
    $stmt -> execute();

    $dados = $stmt->fetchAll();

    if(empty($dados)) {
        $_SESSION["msg"] = "<p style='color: red; text-align: center;'>Não há serviços e/ou peças cadastradas para esta manutenção.<br> Atualize as informações.</p>";
        header('Location: ../atualizar-manutencoes/atualizar.php?id='.$_GET["manutencao"]);
    }

    $ids = array();

    $preco_total = array();

    $servicos_pecas = array();

    for($i = 0; $i < count($dados); $i++) {
        if(!empty($dados[$i]["servico_id"])){
            $sql = 'SELECT * FROM servicos WHERE id = :id';
            $stmt = $PDO -> prepare($sql);
            $stmt -> bindParam(':id', $dados[$i]["servico_id"]);
            $stmt -> execute();

            $servico = $stmt->fetch();

            array_push($servicos_pecas, $servico);

            array_push($preco_total, ($servico["preco_final"]*$dados[$i]["quantidade"]));
        }
    }

    for($i = 0; $i < $dados[0]["qtd_pecas"]; $i++) {
        if(!empty($dados[$i]["peca_id"])){
            $sql = 'SELECT * FROM estoque WHERE id = :id';
            $stmt = $PDO -> prepare($sql);
            $stmt -> bindParam(':id', $dados[$i]["peca_id"]);
            $stmt -> execute();

            $peca = $stmt->fetch();
            $qtd = array('qtd' => $dados[$i]["quantidade"]);

            array_push($peca, $qtd);
            
            array_push($servicos_pecas, $peca);

            array_push($preco_total, ($peca["preco_final"]*$dados[$i]["quantidade"]));
        }
    }

    $placa = $dados[0]["placa"];
    $marca = $dados[0]["marca"];
    $modelo = $dados[0]["modelo"];
    $nome = $dados[0]["proprietario"];
    $nome = $dados[0]["proprietario"];
    $data = $dados[0]["DATE_FORMAT(m.data_inicio, '%d/%m/%Y ')"];
    $km = number_format($dados[0]["quilometragem"], 0, ',', '.');

    $preco_total = number_format(array_sum($preco_total), 2, ',', '.');

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>Orçamento <?php echo $nome." - ".$km."km" ?> </title>

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <style>
        * {
            box-sizing: border-box;
            font-family: sans-serif;
        }

        .txt-right {
            text-align: right;
        }

        .txt-left {
            text-align: left;
        }

        .container {
            max-width: 768px;
            max-height: 100vh;
            
            margin: 0 auto;
            padding: 15px 0;

            /* display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center; */
        }

        header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            align-items: center;
        }

        #logo {
            width: 100px;
            height: 50px;
        }

        thead, tbody {
            text-align: left;
            margin: 0 auto;
        }

        table {
            width: 100%;
        }

        .carro {
            display: grid;
            grid-template-columns: 100px 100px 100px 1fr; 
            grid-gap: 10px; 
        }

        .info {
            /* display: grid;
            grid-template-columns: 50% 20% 10% 20%; 
            grid-gap: 2%;  */
        }

        #revisao {
            display: flex;
            justify-content: space-evenly;
        }

        #preco-total {
            display: flex;
            justify-content: space-between;
        }

        .botoes {
            display: flex;
            justify-content: center;
        }

        #imprimir {
            background-color: #ede165;
            padding: 12px 18px;
            border: none;
            box-shadow: 0 0 8px #ccc;
            cursor: pointer;
            margin: 24px;
            transform: translateX(-50%);
            border-radius: 8px;
            transition: 0.2s;
            border: none;
        }

        #imprimir:hover {
            box-shadow: 0 0 8px #777;
            background-color: #e8d509;
        }

        @media print {
            #imprimir {
                display: none;
            }
        }
    </style>

</head>
<body>
    <main class="container">
        <header>
            <img id="logo" src="../../../images/logo-black.png" alt="Lidio Rosa">
            <p class="txt-right">Rua Bombeiro Eliezer Alexandrino, no. 96, Av. Jorge Amado - Salvador/BA <br> Tel: (71) 3371-6420</span></p>
        </header>
        <hr>
        <main>
            <table>
                <thead>
                    <tr class="carro">
                        <th>Placa</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Nome</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="carro">
                        <td><?php echo $placa?></td>
                        <td><?php echo $marca ?></td>
                        <td><?php echo $modelo ?></td>
                        <td><?php echo $nome ?></td>
                    </tr>
                </tbody>
            </table>

            <hr>
                <p id="revisao"><span>Revisão: <?php echo $data ?></span><span>Quilometragem: <?php echo $km ?>km</span></p>
            <hr>
            <table>
                <thead>
                    <tr class="info">
                        <th style="width: 60%;">Peças/Serviços</th>
                        <th style="width: 15%;" class="txt-right">Pço unit.</th>
                        <th style="width: 10%;" class="txt-right">Qtd</th>
                        <th style="width: 15%;" class="txt-right">Pço Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($info = array_pop($servicos_pecas)){?>
                        <tr class="info">
                        <?php if(!empty($info["servico"])){ ?>
                            <td style="width: 60%;"><?php echo $info["servico"] ?></td>
                            <td style="width: 15%;" class="txt-right"><?php echo "R$ ".number_format($info["preco_final"], 2, ',', '.') ?></td>
                            <td style="width: 10%;" class="txt-right">1</td>
                            <td style="width: 15%;" class="txt-right"><?php echo "R$ ".number_format($info["preco_final"], 2, ',', '.') ?></td>
                        <?php } else { ?>
                            <td style="width: 60%;"><?php echo $info["peca"] ?></td>
                            <td style="width: 15%;" class="txt-right"><?php echo "R$ ".number_format($info["preco_final"], 2, ',', '.') ?></td>
                            <td style="width: 10%;" class="txt-right"><?php echo $info[18]["qtd"] ?></td>
                            <td style="width: 15%;" class="txt-right"><?php echo "R$ ".(number_format($info["preco_final"]*$info[18]["qtd"], 2, ',', '.')) ?></td>
                            <?php }  ?>
                        <tr>
                    <?php } ?>
                </tbody>
            </table>

            <hr>
                <p id="preco-total"><span><b>Total Geral:</b></span> <span><?php echo "R$ ".$preco_total ?></span></p>
            <hr>

            

        </main>
        <div class="botoes">
            <button id="imprimir" onclick="window.print()">Imprimir</button>
            <button id="imprimir" onclick="location.href =' <?php echo (!empty($_GET['page']))?'../atualizar-manutencoes':'../historico' ?>'">Voltar</button>
        </div>
    </main>
</body>
</html>