<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    if(empty($_POST)) {
        header('Location: ./');
    }

    var_dump($_POST);
    var_dump($_FILES);

    $marca = strtoupper($_POST["marca"]);
    $diretorio ='../../../res/img/marcas/';
    $logo = $_FILES["logo"]["name"];

    include_once '../../../php/init.php';
    
    $PDO = db_connect();
    $sql = "INSERT INTO marcas(marca, foto) VALUES (:marca, :logo)";
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':marca', $marca);
    $stmt -> bindParam(':logo', $logo);
    if($stmt -> execute()){
        $ultimo_id = $PDO -> lastInsertId();
        $diretorio .= $ultimo_id."/";
        echo $ultimo_id;
        
        mkdir($diretorio, 0755);

        if(move_uploaded_file($_FILES['logo']['tmp_name'], $diretorio.$logo)){
            $_SESSION['msg'] = "<p style='color: green; text-align: center'>Marca cadastrada com sucesso!</p>";
        } else {
            $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível cadastrar a marca.<br>Tente novamente.</p>";
        }
    }
    
    header("Location: ./");

