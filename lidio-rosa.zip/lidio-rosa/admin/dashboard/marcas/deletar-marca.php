<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    if(empty($_POST)) {
        header('Location: ./');
    }

    $id = $_GET["id"];

    $foto = "../../../res/img/marcas/".$id."/".$_POST["logo"];
    $diretorio = "../../../res/img/marcas/".$id."/";

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'DELETE FROM marcas WHERE id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $id);
    if($stmt -> execute()) {
        unlink($foto);
        rmdir($diretorio);
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Marca excluída com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível excluir a marca.<br>Tente novamente.</p>";
    }

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";
    echo "<script>location.href='./'</script>";