<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    include_once '../../../php/init.php';



    $PDO = db_connect();
    $sql = 'SELECT * FROM marcas WHERE id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $_GET["id"]);
    $stmt -> execute();

    $dados = $stmt -> fetch();

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>LidioDash</title>

  <!-- Favicons -->
  <link href="../../../res/img/favicon.png" rel="icon">
  <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../../../res/css/style.css" rel="stylesheet">
  <link href="../../../res/css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="../../../res/css/my-style.css">
  
  <script src="../../../res/lib/chart-master/Chart.js"></script>

  
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>LIDIO<span>DASH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">

          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../index.html">Sair</a></li>
        </ul>
      </div>
    
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
          <h5 class="centered">
            <?php echo $_SESSION["nome"] ?>
          </h5>
          <li class="mt">
            <a href="../">
              <i class="fa fa-dashboard"></i>
              <span>Lista de Contatos</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../painel-de-controle.php">
              <i class="fa fa-desktop"></i>
              <span>Painel de Controle</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../historico">
              <i class="fa fa-history"></i>
            <span>Histórico</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../fornecedores">
              <i class="fa fa-users"></i>
              <span>Fornecedores</span>
            </a>
          </li>
          <li class="sub-menu">
            <a class="active" href="../marcas">
              <i class="fa fa-tags"></i>
              <span>Marcas</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../servicos">
              <i class="fa fa-wrench"></i>
              <span>Serviços</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../estoque">
              <i class="fa fa-cubes"></i>
              <span>Estoque</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../meus-dados">
              <i class="fa fa-user"></i>
              <span>Meus dados</span>
            </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i> Editar Marca</h3>
        <!-- FORM VALIDATION -->
        <div class="row mt">
          <div class="col-lg-12">
            <h4><i class="fa fa-angle-right"></i> Preencha abaixo o que deseja alterar</h4>
            <div class="form-panel">
              <div class=" form">
                <form class="cmxform form-horizontal style-form" id="commentForm" method="POST" action="edit-marca.php?id=<?php echo $_GET['id'] ?>" enctype="multipart/form-data">
                  <input type="hidden" name="lastLogo" value="<?php echo $dados['foto']?>">
                  <div class="form-group">
                    <label class="col-lg-2 control-label"> Logo da marca</label>
                    <div class="col-lg-6">
                      <input type="file" name="logo" id="file">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="cemail" class="control-label col-lg-2">Nome da Marca</label>
                    <div class="col-lg-4">
                      <input class="form-control " value="<?php echo $dados['marca']?>" type="text" name="marca" required>
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                      <button class="btn btn-theme" type="submit">Salvar</button>
                      <button class="btn btn-theme04" onclick="location.href = './'" type="button">Cancelar</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
        <!-- /row -->
   
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer" id="footer-cadastro">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
        </p>
        <div class="credits">
         
         Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
        </div>
        <a href="adicionar-marca.php" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
        
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../../res/lib/jquery/jquery.min.js"></script>
  <script src="../../../res/lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
  <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../../../res/lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../../../res/lib/common-scripts.js"></script>
  <!--script for this page-->
  <script src="../../../res/lib/sparkline-chart.js"></script>

</body>

</html>
