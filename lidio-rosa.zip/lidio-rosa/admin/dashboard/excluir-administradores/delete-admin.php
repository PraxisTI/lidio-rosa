<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }

    $id = $_GET["id"];

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'DELETE FROM administradores WHERE id = :id LIMIT 1';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $id);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Administrador excluído com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível excluir o administrador.<br>Tente novamente.</p>";
    }

    header('Location: ./');