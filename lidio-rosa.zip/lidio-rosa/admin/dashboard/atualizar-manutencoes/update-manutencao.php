<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }
    
    $placa = strtoupper($_POST["placa"]);
    $placas = $_POST["placas"];
    $dia = implode("-",array_reverse(explode("/",$_POST["data"])));
    
    if(!strpos($placas, $placa)) {
        $_SESSION["msg"] = "<p style='color: red; text-align: center;'>Placa não encontrada no banco de dados. Digite corretamente.</p>";
        header('Location: ./');
    } else {
        include_once '../../../php/init.php';
        
        $PDO = db_connect();
        $sql = 'UPDATE manutencoes SET qtd_servicos = :qtd_serv, qtd_pecas = :qtd_peca WHERE id = :id';
        $stmt = $PDO -> prepare($sql);
        $stmt -> bindParam(':qtd_serv', $_POST["serv_count"]);
        $stmt -> bindParam(':qtd_peca', $_POST["peca_count"]);
        $stmt -> bindParam(':id', $_POST["id"]);
        $stmt -> execute();

        $PDO = db_connect();
        $sql = 'SELECT servico_id, peca_id, quantidade FROM manutencoes_detalhes WHERE manutencao_id=:id';
        $stmt = $PDO -> prepare($sql);
        $stmt -> bindParam(':id', $_POST["id"]);
        $stmt -> execute();

        $last_detail = $stmt -> fetchAll();

        for($i = 0; $i < count($last_detail); $i++) {
            if($last_detail[$i]['peca_id'] != null) {
                $quantidade = $last_detail[$i]['quantidade'];
                $peca_id = $last_detail[$i]['peca_id'];
                $sql = 'UPDATE estoque SET quantidade=quantidade+:quantidade WHERE id = :peca_id';
                $stmt = $PDO -> prepare($sql);
                $stmt -> bindParam(':quantidade', $quantidade);
                $stmt -> bindParam(':peca_id', $peca_id);
                $stmt -> execute();
            } 
        }
        
        $sql = 'DELETE FROM manutencoes_detalhes WHERE manutencao_id=:id; UPDATE manutencoes SET placa=:placa, titulo_manutencao=:titulo_manutencao, descricao=:descricao, quilometragem=:quilometragem, data_inicio=:data_inicio WHERE id=:id LIMIT 1;UPDATE status SET hora=:hora, dia=:dia WHERE id_manutencao=:id AND etapa = 1;';
        $stmt = $PDO -> prepare($sql);
        $stmt -> bindParam(':placa', $placa);
        $stmt -> bindParam(':quilometragem', $_POST["quilometragem"]);
        $stmt -> bindParam(':data_inicio', $dia);
        $stmt -> bindParam(':titulo_manutencao', $_POST["titulo_manutencao"]);
        $stmt -> bindParam(':descricao', $_POST["descricao"]);
        $stmt -> bindParam(':id', $_POST["id"]);
        $stmt -> bindParam(':dia', $dia);
        $stmt -> bindParam(':hora', $_POST["hora"]);
        if($stmt -> execute()) {
            
            $id_mantencao = $_POST["id"];

            for($i = 0; $i < $_POST["peca_count"]; $i++) {
                $id_peca = "id-peca-".($i+1);
                $id_peca = $_POST[$id_peca];
                $qtd_peca = "qtd-".($i+1);
                $qtd_peca = $_POST[$qtd_peca];
                
                $PDO = db_connect();
                $sql = 'INSERT INTO manutencoes_detalhes(manutencao_id, peca_id, quantidade) VALUES (:manutencao_id, :peca_id, :quantidade);UPDATE estoque SET quantidade=quantidade-:quantidade WHERE id=:peca_id AND quantidade > 0';
                $stmt = $PDO -> prepare($sql);
                $stmt -> bindParam(':manutencao_id', $id_mantencao);
                $stmt -> bindParam(':peca_id', $id_peca);
                $stmt -> bindParam(':quantidade', $qtd_peca);
                $stmt -> execute();
            }

            for($i = 0; $i < $_POST["serv_count"]; $i++) {
                $id_serv = "id-serv-".($i+1);
                $id_serv = $_POST[$id_serv];

                $PDO = db_connect();
                $sql = 'INSERT INTO manutencoes_detalhes(manutencao_id, servico_id) VALUES (:manutencao_id, :servico_id);';
                $stmt = $PDO -> prepare($sql);
                $stmt -> bindParam(':manutencao_id', $id_mantencao);
                $stmt -> bindParam(':servico_id', $id_serv);
                $stmt -> execute();
            }
            
            // $_SESSION["msg"] = "<p style='color: green; text-align: center'>Manutenção atualizada com sucesso!</p>";
        } else {
            $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível atualizar a manutenção. Tente novamente.</p>";
            header('Location: ./');
        }
    }
    $page = $_GET['page'];
    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";
    echo "<script>location.href='../relatorio/index.php?manutencao=$id_mantencao&page=$page'</script>";