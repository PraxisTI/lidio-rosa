<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'SELECT m.id, c.email, TIME_FORMAT(hora, \'%H:%i\'), c.proprietario, DATE_FORMAT(data_inicio, \'%d/%m/%Y\'), c.placa, m.titulo_manutencao, m.descricao, m.quilometragem, c.info_proprietario, c.profissao, c.foto_user, DATE_FORMAT(data_inicio, "%d\.%m\.%Y") FROM manutencoes AS m JOIN carros AS c ON c.placa = m.placa JOIN status AS s ON m.id = s.id_manutencao WHERE m.id=:id AND s.etapa = 1 ORDER BY data_inicio DESC ';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $_GET["id"]);
    $stmt -> execute();
    $dados = $stmt -> fetch();

    $data = $dados["DATE_FORMAT(data_inicio, \"%d\.%m\.%Y\")"];
    $foto = '../../../res/img/users_img/'.$dados["foto_user"];

    $PDO = db_connect();
    $sql2 = 'SELECT placa FROM carros';
    $stmt2 = $PDO -> prepare($sql2);
    $stmt2 -> execute();

    $placas = "";
    while($dados2 = $stmt2 -> fetch()) {
        $placas = $placas."'".$dados2["placa"]."',";
    }
    
    $placas = substr($placas,0,-1);


    $PDO = db_connect();
    $sql2 = 'SELECT COUNT(id) AS qtdVisitas FROM manutencoes WHERE placa = :placa';
    $stmt2 = $PDO -> prepare($sql2);
    $stmt2 -> bindParam(':placa', $dados["placa"]);
    $stmt2 -> execute();
    $qtd = $stmt2 -> fetch()[0];

    $PDO = db_connect();
    $sql = 'SELECT id, servico FROM servicos ORDER BY servico ASC';
    $stmt = $PDO -> prepare($sql);
    $stmt -> execute();

    $servicos = json_encode($stmt -> fetchAll());

    $PDO = db_connect();
    $sql = 'SELECT id, peca FROM estoque ORDER BY peca ASC';
    $stmt = $PDO -> prepare($sql);
    $stmt -> execute();
    
    $pecas = json_encode($stmt -> fetchAll());
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link rel="stylesheet" href="../../../res/css/preenchimento-automatico.css">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">

    <link rel="stylesheet" href="../../../res/css/my-style.css">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
    TOP BAR CONTENT & NOTIFICATIONS
    *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="../index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
    MAIN SIDEBAR MENU
    *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered">
                        <?php echo $_SESSION["nome"] ?>
                    </h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
    MAIN CONTENT
    *********************************************************************************************************************************************************** -->
        <!--main content start-->

        <!-- Content Wrapper. Contains page content -->
        <section id="main-content">
            <section class="wrapper site-min-height">
                <div class="row mt">
                    <div class="col-lg-12 px-5">
                        <!-- Content Header (Page header) -->
                        <section class="content-header">
                            <div class="container-fluid">
                                <div class="row mb-2">
                                    <div class="col-sm-6">
                                        <h3><i class="fa fa-angle-right"></i> Atualizar Manutenção
                                    </div>
                                    <div class="col-sm-6">
                                        <ol class="breadcrumb float-sm-right">
                                            <li class="breadcrumb-item"><a href="../">Início</a></li>
                                            <li class="breadcrumb-item active">Painel de Controle</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <div class="row content-panel">
                            <div class="col-md-4 profile-text mt mb centered">
                                <div class="right-divider hidden-sm hidden-xs">
                                    <h4><?php echo $dados["placa"]?></h4>
                                    <h6>PLACA DO CARRO</h6>
                                    <h4><?php echo $data ?></h4>
                                    <h6>DATA DE CHEGADA</h6>
                                    <h4><?php echo $qtd ?></h4>
                                    <h6>NÚMERO DE VISITAS A LOJA</h6>
                                </div>
                            </div>
                            <!-- /col-md-4 -->
                            <div class="col-md-4 profile-text">
                                <h3><?php echo $dados["proprietario"]?></h3>
                                <h6><?php echo $dados["profissao"]?></h6>
                                <p><?php echo $dados["info_proprietario"]?></p>
                                <br>
                                <?php if(!empty($dados["email"]) && strpos($dados["email"], '@')) {?>
                                    <p><a href="mailto:<?php echo $dados["email"]?>" class="btn btn-theme"><i class="fa fa-envelope"></i> Enviar
                                        Mensagem</a></p>
                                <?php } else { ?>
                                    <p>E-mail não informado</p>
                                <?php } ?>
                            </div>
                            <!-- /col-md-4 -->
                            <div class="col-md-4 centered">
                                <div class="profile-pic">
                                    <p><img src="<?php echo $foto ?>" class="img-circle"></p>
                                </div>
                            </div>
                            <!-- /col-md-4 -->
                        </div>
                        <!-- /row -->
                    </div>

                    <!-- Main content -->
                    <div class="col-lg-12 mt">
                        <div class=" content-panel">
                            <!-- /tab-pane -->
                            <div id="edit" class="tab-pane">
                                <div class="row justify-content-center">
                                    <div class="col-lg-8 detailed">
                                        <h4 class="mb"> Informação da Manutenção</h4>
                                        <?php
                                        if(!empty($_SESSION["msg"])) {
                                            echo $_SESSION["msg"];
                                            unset($_SESSION["msg"]);
                                        }
                                    ?>
                                        <form method="POST" action="update-manutencao.php">
                                            <div class="w-70 justify-content-center row">
                                                <input type="hidden" name="id" value="<?php echo $_GET["id"] ?>">
                                                <input type="hidden" name="placas" value="<?php echo $placas ?>">
                                                <div class="form-group col-4 p-0 pr-md-2">
                                                    <label for="placa">Placa*</label>
                                                    <div class="">
                                                        <input type="text" name="placa" id="placa" class="form-control" value="<?php echo $dados["placa"] ?>" required>
                                                    </div>
                                                </div>
                                                <div class="form-group col-4 p-0 pl-md-2">
                                                    <label class="">Quilometragem*</label>
                                                    <div class="">
                                                        <input pattern="[0-9\.]{1,}" type="text" name="quilometragem" id="quilometragem" class="form-control" value="<?php echo $dados["quilometragem"] ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 justify-content-center row">
                                                <div class="form-group col-4 p-0 pr-md-2">
                                                    <label for="data">Data*</label>
                                                    <div class="">
                                                        <input type="text" onkeypress="mascaraData(this)" onkeyup="mascData(this)" maxlength="10" name="data" id="data" class="form-control" value="<?php echo $dados["DATE_FORMAT(data_inicio, '%d/%m/%Y')"] ?>" required>
                                                    </div>
                                                </div>
                                                <div class="form-group col-4 p-0 pl-md-2">
                                                    <label class="">Horário*</label>
                                                    <div class="">
                                                        <input type="text" maxlength="5" onkeyup="masc(this)" onkeypress="mascaraHora(this)" value="<?php echo $dados["TIME_FORMAT(hora, '%H:%i')"] ?>" pattern="([0-9]{2}:[0-9]{2})" name="hora" id="hora" class="form-control"
                                                            required placeholder="09:00">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 row justify-content-center">
                                                <div class="col-8 p-0">
                                                    <div class="form-group">
                                                        <label class="">Título da manutenção*</label>
                                                        <div class="">
                                                            <input type="text" class="form-control" id="titulo_manutencao" name="titulo_manutencao" value="<?php echo $dados["titulo_manutencao"] ?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 row justify-content-center">
                                                <div class="col-12">
                                                    <div class="form-group" style="display: flex; justify-content: space-around;">
                                                        <p class="mb-0">Adicionar Serviço</p>
                                                        <button style="background-color: transparent; border: none;" onclick="addServico(); event.preventDefault();"><i class="fa fa-plus-circle"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 row justify-content-center">
                                                <div class="col-12">
                                                    <div class="form-group w-70 px-2" id="servicos">
                                                        <input type="hidden" id="serv_count" name="serv_count">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 row justify-content-center">
                                                <div class="col-12">
                                                    <div class="form-group" style="display: flex; justify-content: space-around;">
                                                        <p class="mb-0 pr-4">Adicionar Peça</p>
                                                        <button style="background-color: transparent; border: none;" onclick="addPeca(); event.preventDefault();"><i class="fa fa-plus-circle"></i></button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 row justify-content-center">
                                                <div class="col-12">
                                                    <div class="form-group w-70 px-2" id="pecas">
                                                        <input type="hidden" id="peca_count" name="peca_count">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="w-70 row justify-content-center">
                                                <div class="col-8 p-0">
                                                    <div class="form-group">
                                                        <label class="">Descrição da manutenção*</label>
                                                        <div class="">
                                                            <textarea class="form-control" id="descricao" name="descricao" style="resize: none; height: 106px" required><?php echo $dados["descricao"] ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group w-70 mt-5">
                                                <div class="d-flex justify-content-center">
                                                    <button class="btn btn-theme mr-2" type="submit" id="btn-salvar" name="submit"
                                                        value="Enviar">Salvar</button>
                                                    <button class="btn btn-theme04 ml-2" type="button"
                                                        onclick="location.href = '../painel-de-controle.php'">Cancelar</button>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                    <!-- /col-lg-8 -->
                                </div>
                                <!-- /row -->

                            </div>
                        </div>
                    </div>
                </div>


                <!-- /.content-wrapper -->
            </section>
        </section>

        <!--footer start-->
        <footer class="site-footer" id="footer-cadastro">
            <div class="text-center">
                <p>
                    &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                </p>
                <div class="credits">

                    Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                </div>
                <a href="atualizar.php" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->

    </section>

    <!-- jQuery -->
    <script src="../../../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../../../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../../../res/lib/common-scripts.js"></script>
    <script>
        var count_serv = 1;

        function addServico() {
            let div = document.createElement("div");
            div.classList.add('autocomplete')

            let hiddenInput = document.createElement("input");
            hiddenInput.type = "hidden";
            hiddenInput.id = "id-serv-"+count_serv;
            hiddenInput.name = "id-serv-"+count_serv;

            let textfield = document.createElement("input");
            textfield.type = "text";
            textfield.name = "serv-"+count_serv;
            textfield.id = "serv-"+count_serv;
            textfield.value = "";
            textfield.classList.add('form-control')
            textfield.style.marginTop = "10px";
            if(count_serv == 1) {
                textfield.style.marginTop = "-40px";
            }
            
            document.getElementById('servicos').appendChild(div).appendChild(textfield);
            document.getElementById('servicos').appendChild(div).appendChild(hiddenInput);

            autocomplete(document.getElementById(textfield.id), lista_servicos, hiddenInput.id)

            document.querySelector('#serv_count').value = count_serv;
            count_serv++;
        }

        var count_peca = 1;

        function addPeca() {
            document.querySelector('#peca_count').value = count_peca;

            let div = document.createElement("div");
            div.classList.add('autocomplete')
            div.style.width = "100%"
            div.style.display = "flex"
            div.style.justifyContent = "justify-between"

            let hiddenInput = document.createElement("input");
            hiddenInput.type = "hidden";
            hiddenInput.id = "id-peca-"+count_peca;
            hiddenInput.name = "id-peca-"+count_peca;
            
            let textfield = document.createElement("input");
            textfield.type = "text";
            textfield.name = "peca-"+count_peca;
            textfield.id = "peca-"+count_peca;
            textfield.value = "";
            textfield.placeholder = "Peça";
            textfield.classList.add('form-control')
            textfield.style.marginTop = "10px";
            textfield.style.width = "80%";
            if(count_peca == 1) {
                textfield.style.marginTop = "-40px";
            }

            let qtdInput = document.createElement("input");
            qtdInput.type = "text";
            qtdInput.name = "qtd-"+count_peca;
            qtdInput.id = "qtd-"+count_peca;
            qtdInput.value = "";
            qtdInput.placeholder = "Quantidade";
            qtdInput.classList.add('form-control')
            qtdInput.style.marginTop = "10px";
            qtdInput.style.marginLeft = "2%";
            qtdInput.style.width = "18%";
            if(count_peca == 1) {
                qtdInput.style.marginTop = "-40px";
            }

            document.getElementById('pecas').appendChild(div).appendChild(textfield);
            document.getElementById('pecas').appendChild(div).appendChild(qtdInput);
            document.getElementById('pecas').appendChild(div).appendChild(hiddenInput);

            autocomplete(document.getElementById(textfield.id), lista_pecas, hiddenInput.id)

            document.querySelector('#peca_count').value = count_peca;
            count_peca++;

        }

        var sizeHora = 0;
        var sizeData = 0;
        
        function mascaraHora(e) {
            console.log(e.value.length);
            if(e.value.length==2 && sizeHora < e.value.length){
                e.value += ':'
            }

            
            sizeHora = e.value.length
        }

        function masc(e) {
            if(e.value.length == 0) {
                document.querySelector('#btn-salvar').disabled = false
                    e.style.borderColor = '#ccc';
            }
            if(e.value.length == 5) {
                if((e.value.split(":", 2)[0] >= 24) || (e.value.split(":", 2)[1] >= 60)) {
                    document.querySelector('#btn-salvar').disabled = true
                    e.style.borderColor = 'red';
                } else {
                    document.querySelector('#btn-salvar').disabled = false
                    e.style.borderColor = 'green';
                }
            }
        }

        function mascaraData(e) {
            console.log(e.value.length);
            if((e.value.length==2 || e.value.length==5 )&& sizeData < e.value.length){
                e.value += '/'
            }

            
            sizeData = e.value.length
        }

        function mascData(e) {
            if(e.value.length == 0) {
                document.querySelector('#btn-salvar').disabled = false
                    e.style.borderColor = '#ccc';
            }
            if(e.value.length == 10) {
                if((e.value.split("/", 2)[0] > 31) || (e.value.split("/", 2)[1] > 12)) {
                    document.querySelector('#btn-salvar').disabled = true
                    e.style.borderColor = 'red';
                } else {
                    document.querySelector('#btn-salvar').disabled = false
                    e.style.borderColor = 'green';
                }
            }
        }

        <?php 
            echo "var lista_servicos = ". $servicos . ";\n"; 
            echo "var lista_pecas = ". $pecas . ";\n"; 
        ?>

    </script>

    <script>
    function autocomplete(inp, arr, number_id) {
      /*the autocomplete function takes two arguments,
      the text field element and an array of possible autocompleted values:*/
      var currentFocus;
      /*execute a function when someone writes in the text field:*/
      inp.addEventListener("input", function(e) {
        //   console.log(arr)
        //   console.log(inp)
        //   console.log(number)
          var a, b, i, val = this.value;
          let id = "";
          /*close any already open lists of autocompleted values*/
          closeAllLists();
          if (!val) { return false;}
          currentFocus = -1;
          /*create a DIV element that will contain the items (values):*/
          a = document.createElement("DIV");
          a.setAttribute("id", this.id + "autocomplete-list");
          a.setAttribute("class", "autocomplete-items");
          /*append the DIV element as a child of the autocomplete container:*/
          this.parentNode.appendChild(a);
          /*for each item in the array...*/
          for (i = 0; i < arr.length; i++) {
            id = arr[i][0];
            // console.log(arr[i][0])

            /*check if the item starts with the same letters as the text field value:*/
            if (arr[i][1].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
              /*create a DIV element for each matching element:*/
              b = document.createElement("DIV");
              /*make the matching letters bold:*/
              b.innerHTML = "<strong>" + arr[i][1].substr(0, val.length) + "</strong>";
              b.innerHTML += arr[i][1].substr(val.length);
              /*insert a input field that will hold the current array item's value:*/
              b.innerHTML += "<input type='hidden' value='" + arr[i][1] + "' id='" + arr[i][0] + "'>";
              /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
                  /*insert the value for the autocomplete text field:*/
                  //console.log(this.querySelector('input').value)
                  inp.value = this.querySelector('input').value
                  /*close the list of autocompleted values,
                  (or any other open lists of autocompleted values:*/
                  document.querySelector("#"+number_id).value = this.querySelector('input').id
                //   console.log(this.querySelector('input').id)

                  closeAllLists();
              });
              a.appendChild(b);
            }
          }
      });

      inp.addEventListener("keydown", function(e) {
          var x = document.getElementById(this.id + "autocomplete-list");
          if (x) x = x.getElementsByTagName("div");
          if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
            increase the currentFocus variable:*/
            currentFocus++;
            /*and and make the current item more visible:*/
            addActive(x);
          } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
            decrease the currentFocus variable:*/
            currentFocus--;
            /*and and make the current item more visible:*/
            addActive(x);
          } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if (currentFocus > -1) {
              /*and simulate a click on the "active" item:*/
              if (x) x[currentFocus].click();
            }
          }
      });

      function addActive(x) {
        /*a function to classify an item as "active":*/
        if (!x) return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (currentFocus >= x.length) currentFocus = 0;
        if (currentFocus < 0) currentFocus = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[currentFocus].classList.add("autocomplete-active");
      }

      function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
          x[i].classList.remove("autocomplete-active");
        }
      }

      function closeAllLists(elmnt) {
        /*close all autocomplete lists in the document,
        except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
          if (elmnt != x[i] && elmnt != inp) {
            x[i].parentNode.removeChild(x[i]);
          }
        }
      }

      document.addEventListener("click", function (e) {
          closeAllLists(e.target);
      });
      
    }   
    </script>
</body>

</html>