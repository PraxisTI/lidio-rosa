<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
        
    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'UPDATE administradores SET email=:email, senha=:senha, nome=:nome WHERE id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':email', $_POST["email"]);
    $stmt -> bindParam(':senha', $_POST["nova_senha"]);
    $stmt -> bindParam(':nome', $_POST["nome"]);
    $stmt -> bindParam(':id', $_SESSION["admin_id"]);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Administrador atualizado com sucesso!</p>";
        $_SESSION["nome"] = $_POST["nome"];
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível atualizar o administrador.<br>Tente novamente.</p>";
    }

    header('Location: ./');