<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../../');
  }

  include_once '../../../php/init.php';

  $inicio = $_GET["ano"].'-'.$_GET["mes"].'-'.'01';
  $fim = $_GET["ano"].'-'.($_GET["mes"]+1).'-'.'01';
  
  $tipo = ($_GET["tipo"]=='peca') ? 'd.peca_id' : 'd.servico_id';

  $PDO = db_connect();
  $sql = "SELECT m.id, d.quantidade, ".$tipo." FROM manutencoes AS m JOIN manutencoes_detalhes AS d ON m.id = d.manutencao_id WHERE m.data_inicio >= :inicio AND m.data_inicio <= :fim";
  $stmt = $PDO -> prepare($sql);
  $stmt -> bindParam(':inicio', $inicio);
  $stmt -> bindParam(':fim', $fim);
  $stmt -> execute();

  $faturamento = 0;

  while ($dado = $stmt -> fetch()) {
    // $sql = 'SELECT preco_final FROM estoque LIMIT 1';
    // $stmt2 = $PDO -> prepare($sql);
    // $stmt2 -> execute();

    // var_dump($stmt2->fetch());


    if($_GET["tipo"] == 'peca') {
      $id = $dado['peca_id'];
      $sql = 'SELECT preco_final FROM estoque WHERE id = :id';
    } else {
      $id = $dado['servico_id'];
      $sql = 'SELECT preco_final FROM servicos WHERE id = :id';
    }
    
    if ((array_key_exists('peca_id', $dado) && $dado['peca_id'] != null) || (array_key_exists('servico_id', $dado) && $dado['servico_id'] != null)) {
      $stmt2 = $PDO -> prepare($sql);
      $stmt2 -> bindParam(':id', $id);
      $stmt2 -> execute();
      $valor = $stmt2 -> fetch()["preco_final"];
      
      $faturamento += ($dado["quantidade"] * $valor);
    }
  }

  $faturamento = number_format($faturamento, 2, ',', '.');

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">

    <link rel="stylesheet" href="../../../res/css/my-style.css">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
    TOP BAR CONTENT & NOTIFICATIONS
    *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="../" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
    MAIN SIDEBAR MENU
    *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered">
                        <?php echo $_SESSION["nome"] ?>
                    </h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
    MAIN CONTENT
    *********************************************************************************************************************************************************** -->
        <!--main content start-->

      <section id="main-content">
        <section class="wrapper-1 ">
          <section class="content-header">
            <div class="container-fluid">
              <div class="row mb-2">
                <div class="col-sm-6">
                  <h3><i class="fa fa-angle-right"></i> Relatório de Faturamento
                </div>
                <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="index.php">Início</a></li>
                    <li class="breadcrumb-item active">Painel de Controle</li>
                  </ol>
                </div>
              </div>
            </div>
            <!-- /.container-fluid -->
          </section>

          <div class="mx-5">
            <p>Este relatório é emitido após informar o mês e ano. O sistema totaliza os serviços ou peças realizados no mês e ano informado, conforme tela abaixo. <br>O relatório abaixo é o resultado da pesquisa do faturamento mensal.</p>

            <h4 class="mt-5"><strong>Relatório de faturamento de <?php echo (($_GET["tipo"] == 'servico')?'serviços prestados ':'peças vendidas ').'em '.$_GET['mes'].'/'.$_GET['ano']  ?></strong></h4>
            <h5>Faturamento total: R$ <?php echo $faturamento ?></h5>
            
            <br>
            
            <small>
            <?php 
              if($faturamento == '0,00') {
                echo 'Não foram encontrado registros para o mês e ano informados, certifique-se de ter informado os dados corretamente.<br> Caso os problemas continuem, certifique-se de que o período informado é posterior a atualização do sistema.';
              }
            ?>
            </small>
          </div>
        </section>
      </section>
        
    </section>
    <!-- jQuery -->
    <script src="../../../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../../../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../../../res/lib/common-scripts.js"></script>
</body>

</html>