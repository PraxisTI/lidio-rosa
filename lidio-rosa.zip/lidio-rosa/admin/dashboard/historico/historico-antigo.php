<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../');
    }

    $placa = $_GET["placa"];

    include_once '../../../php/init.php';

    date_default_timezone_set('America/Sao_Paulo');

    $PDO = db_connect();
    $sql = "SELECT * FROM carros WHERE placa = :placa";
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $placa);
    $stmt -> execute();
    $infoCarro = $stmt -> fetch();


    $sql = 'SELECT *, DATE_FORMAT(data, \'%d %b. %Y\') FROM tabela_historico AS h WHERE h.id_veiculo = :placa ORDER BY data ASC';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $placa);
    $stmt -> execute();

    $dados = $stmt -> fetchAll();
    $qtd = count($dados);
    
    setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/my-style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>
<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../php/logout.php">Sair</a></li>
                </ul>
            </div>
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered">
                        <?php echo $_SESSION["nome"] ?>
                    </h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->

        <section id="main-content">
            <section class="wrapper-1 ">

                <div class="col-lg-12">
                    <!-- Content Header (Page header) -->
                    <section class="content-header">
                        <div class="container-fluid">
                            <div class="row mb-2">
                                <div class="col-sm-6">
                                    <h1><i class="fa fa-clock" style="color: #797979;"></i> Histórico</h1>
                                    <div class="row" style="margin: 8px 0 0 20px; font-size: 15px;">
                                        <h1 class="mr-5">CARRO: <?php echo $infoCarro["marca"]." ".$infoCarro["modelo"]."-".$infoCarro["ano"] ?></h1>
                                        <h1>PLACA: <?php echo $infoCarro["placa"] ?></h1>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <ol class="breadcrumb float-sm-right">
                                        <li class="breadcrumb-item"><a href="index.php">Início</a></li>
                                        <li class="breadcrumb-item active">Histórico</li>
                                    </ol>
                                </div>
                                <a style="margin-left: 37px;" href="historico.php?placa=<?php echo $infoCarro["placa"] ?>">Voltar</a>
                            </div>
                        </div><!-- /.container-fluid -->
                    </section>

                    <!-- Main content -->
                    <section class="content">
                        <div class="container-fluid">

                            <!-- Timelime example  -->
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- The time line -->
                                    <div class="">
                                        <?php
                                            for($i = 0; $i < $qtd; $i++) {
                                                $km = implode(".", array_map("strrev", array_reverse(str_split(strrev(implode("", explode(".", $dados[$i]["quilometragem"]))), 3))));
                                                $data = ucfirst( utf8_encode(strftime("%d %b. %Y", strtotime($dados[$i]["DATE_FORMAT(data, '%d %b. %Y')"]))));
                                                $historico = $dados[$i]["historico"];
                                                if($i == 0) {
                                                    $km_anterior = "";
                                                    $data_anterior = "";
                                                }
                                                echo ($data != $data_anterior && $i != 0)?"<br><br>":"";
                                                if($i == 0) {                                                    
                                        ?>
                                            <div class="d-flex row ml-4 p-0" style="width: 80%;">
                                                <p class="col-2 font-weight-bold">Data</p>
                                                <p class="col-2 font-weight-bold">Quilometragem</p>
                                                <p class="col-6 font-weight-bold">Serviço ou troca de peça</p>
                                            </div>
                                        <?php   }
                                        ?>


                                            <div class="d-flex row ml-4 p-0" style="width: 80%;">
                                                <p class="col-2"><?php echo ($data != $data_anterior)?$data:"" ?></p>
                                                <p class="col-2"><?php echo ($km != $km_anterior)?$km." km":"" ?></p>
                                                <p class="col-6"><?php echo $historico ?></p>
                                            </div>

                                        <?php    
                                                $km_anterior = $km;
                                                $data_anterior = $data;
                                            } 
                                        ?>
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>
                        </div>
                        <!-- /.timeline -->

                    </section>
                    <!-- /.content -->
                </div>

                <!-- /.content-wrapper -->
            </section>
        </section>

        <!--footer start-->
        <footer class="site-footer" id="footer-cadastro">
            <div class="text-center">
                <p>
                    &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                </p>
                <div class="credits">

                    Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                </div>
                <a href="historico" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->




    </section>
 
    <!-- jQuery -->
    <script src="../../../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../../../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../../../res/lib/common-scripts.js"></script>

</body>

</html>