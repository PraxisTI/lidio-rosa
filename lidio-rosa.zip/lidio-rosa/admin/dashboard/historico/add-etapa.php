<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../');
  }

  if(empty($_GET) || empty($_POST)) {
    header('Location: ./');
  }

  $dia = implode("-",array_reverse(explode("/",$_POST["dia"])));

  include_once '../../../php/init.php';

  $PDO = db_connect();
  $sql = 'INSERT INTO status(id_manutencao, etapa, descricao_etapa, hora, dia) VALUES (:id_manutencao, :etapa, :descricao_etapa, :hora, :dia)';
  $stmt = $PDO -> prepare($sql);
  $stmt -> bindParam(':id_manutencao', $_GET["id"]);
  $stmt -> bindParam(':etapa', $_POST["etapa"]);
  $stmt -> bindParam(':descricao_etapa', $_POST["descricao_etapa"]);
  $stmt -> bindParam(':dia', $dia);
  $stmt -> bindParam(':hora', $_POST["hora"]);
  if($stmt -> execute()) {
    $_SESSION["msg"] = "<p style='color: green; text-align: center'>Status da manutenção atualizado com sucesso!</p>";
  } else {
    $_SESSION["msg"] = "<p style='color: red; text-align: center'>Erro ao atualizar status da manutenção.</p>";
  }

  header('Location: timeline.php?id='.$_GET["id"]);