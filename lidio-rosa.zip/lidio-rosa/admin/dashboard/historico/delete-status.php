<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../');
  }

  if(empty($_GET) || empty($_POST)) {
    header('Location: ./');
  }

  $id = $_GET["id"];
  $id_manutencao = $_POST["id_manutencao"];

  include_once '../../../php/init.php';

  $PDO = db_connect();
  $sql = 'DELETE FROM status WHERE id=:id';
  $stmt = $PDO -> prepare($sql);
  $stmt -> bindParam(':id', $id);
  if($stmt -> execute()) {
    $_SESSION["msg"] = "<p style='color: green; text-align: center'>Status da manutenção atualizado com sucesso!</p>";
  }

  header('Location: timeline.php?id='.$id_manutencao);