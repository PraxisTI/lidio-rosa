<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../');
  }

  if((empty($_SESSION["msg"]) && empty($_GET))) {
    header('Location: ./');
  }

  if(!empty($_SESSION["msg"])) {
    unset($_SESSION["msg"]);
  }

  $id_manutencao = $_GET['id'];
  // echo $id_manutencao;

  $ultima_etapa = 8;

  include_once '../../../php/init.php';

  $PDO = db_connect();
  $sql = 'SELECT *, s.id, TIME_FORMAT(hora, \'%H:%i\'), DATE_FORMAT(dia, \'%d %b. %Y\') FROM status AS s JOIN manutencoes AS m ON m.id = s.id_manutencao AND s.id_manutencao=:id_manutencao ORDER BY dia, hora ASC';
  $stmt = $PDO -> prepare($sql);
  $stmt -> bindParam(':id_manutencao', $id_manutencao);
  $stmt -> execute();
  
  $dados = $stmt->fetchAll();
  $qtd = count($dados);

  if(empty($dados)) {
    $PDO = db_connect();
    $sql = 'SELECT * FROM manutencoes WHERE id=:id_manutencao';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id_manutencao', $id_manutencao);
    $stmt -> execute();
    $dados = $stmt->fetchAll();
  }

  setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');

  $finalizado = false;

  function selectIcon($etapa) {
    $result = array();
    switch ($etapa) {
      case '1':
        $icon = "<i class='fa fa-car bg-primary'></i>";
        $status_etapa = "Chegada";
        array_push($result, $icon, $status_etapa);

      case '2':
        $icon = "<i class='fa fa-search bg-red'></i>";
        $status_etapa = "Análise";
        array_push($result, $icon, $status_etapa);
        break;
      
      case '3':
        $icon = "<i class='fa fa-plus bg-red'></i>";
        $status_etapa = "Diagnóstico";
        array_push($result, $icon, $status_etapa);
        break;
      
      case '4':
        $icon = "<i class='fa fa-sort bg-yellow'></i>";
        $status_etapa = "Elevador";
        array_push($result, $icon, $status_etapa);
        break;
        
      case '5':
        $icon = "<i class='fa fa-clock bg-yellow'></i>";
        $status_etapa = "Andamento";
        array_push($result, $icon, $status_etapa);
        break;
        
      case '6':
        $icon = "<i class='fa fa-paint-brush bg-yellow'></i>";
        $status_etapa = "Finalizando";
        array_push($result, $icon, $status_etapa);
        break;

      case '7':
        $icon = "<i class='fa fa-clock bg-yellow'></i>";
        $status_etapa = "Espera";
        array_push($result, $icon, $status_etapa);
        break;

      case '8':
        $icon = "<i class='fa fa-check bg-green'></i>";
        $status_etapa = "Pronto";
        array_push($result, $icon, $status_etapa);
        break;
        
      default:
        
        break;
    }
    return $result;
  }

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
  <meta name="keyword" content="LidioDash, Lidio, Rosa">
  <title>LidioDash</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../../res/css/all.min.css">
  <!-- AdminLTE css -->
  <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!-- Favicons -->
  <link href="../../../res/img/favicon.png" rel="icon">
  <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="../../../res/css/style.css" rel="stylesheet">
  <link href="../../../res/css/my-style.css" rel="stylesheet">
  <link href="../../../res/css/style-responsive.css" rel="stylesheet">
  <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>
<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">

          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
          <h5 class="centered"><?php echo $_SESSION["nome"] ?></h5>
          <li class="mt">
              <a href="../">
                  <i class="fa fa-dashboard"></i>
                  <span>Lista de Contatos</span>
              </a>
          </li>
          <li class="sub-menu">
              <a href="../painel-de-controle.php">
                  <i class="fa fa-desktop"></i>
                  <span>Painel de Controle</span>
              </a>
          </li>
          <li class="sub-menu">
            <a class="active" href="../historico">
              <i class="fa fa-history"></i>
              <span>Histórico</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../fornecedores">
              <i class="fa fa-users"></i>
              <span>Fornecedores</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../marcas">
              <i class="fa fa-tags"></i>
              <span>Marcas</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../servicos">
              <i class="fa fa-wrench"></i>
              <span>Serviços</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../estoque">
              <i class="fa fa-cubes"></i>
              <span>Estoque</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../meus-dados">
              <i class="fa fa-user"></i>
              <span>Meus dados</span>
            </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->

  <!-- Content Wrapper. Contains page content -->
  <section id="main-content">
    <section class="wrapper-1 ">
    
      <div class="col-lg-12">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 style="font-size: 24px; margin-bottom: 8px;"><?php echo $dados[0]["titulo_manutencao"] ?></h1>
            <h1>Linha do Tempo</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Início</a></li>
              <li class="breadcrumb-item active">Linha do Tempo</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
        <!-- Timelime example  -->
        <div class="row">
          <div class="col-md-12">
            <!-- The time line -->
            <div class="timeline">
              <?php
                for($i = 0; $i < $qtd; $i++) {
                  if(empty($data)) {
                    $data = $dados[$i]["DATE_FORMAT(dia, '%d %b. %Y')"]?>
                    <div class="time-label">
                      <span class="bg-gray"><?php echo $dados[$i]["DATE_FORMAT(dia, '%d %b. %Y')"] ?></span>
                    </div>
                  <?php } 
                    $dados_etapa = selectIcon($dados[$i]["etapa"]);
                    $link_editar_status = "editar-status.php?id_etapa=".$dados[$i]["id"];
                    if($dados[$i]["etapa"] == $ultima_etapa) {
                      $finalizado = true;
                    }
                    if(strcmp($dados[$i]["DATE_FORMAT(dia, '%d %b. %Y')"], $data) != 0) { 
                      $data = $dados[$i]["DATE_FORMAT(dia, '%d %b. %Y')"];
                    ?>
                      <div class="time-label">
                        <span class="bg-gray"><?php echo $dados[$i]["DATE_FORMAT(dia, '%d %b. %Y')"] ?></span>
                      </div>
                    <?php } ?>
                    <div>
                      <?php echo $dados_etapa[0] ?>
                      <div class="timeline-item">
                        <span class="time"><?php if($dados[$i]["etapa"] != 1) { ?>
                            <span class='mr-1'>
                            <?php } else { ?>
                            <span class='mr-5'>
                            <?php } ?>
                            <i class="fa fa-clock"></i> <?php echo $dados[$i]["TIME_FORMAT(hora, '%H:%i')"] ?></span>
                          <?php if($dados[$i]["etapa"] != 1) { ?>
                            <form action="delete-status.php?id=<?php echo $dados[$i]["id"] ?>" method="post" class="d-inline">
                              <input type="hidden" name="id_manutencao" value="<?php echo $_GET["id"] ?>">
                              <button name="Deletar" value="Deletar" class="btn btn-danger btn-xs mr-2"><i class="fa fa-trash-o "></i></button>
                            </form>
                          <?php } ?>
                          <form action="<?php echo $link_editar_status ?>" method="post" class="d-inline">
                            <input type="hidden" name="id_manutencao" value="<?php echo $_GET["id"] ?>">
                            <button name="Editar" value="Editar" class="btn btn-primary btn-xs"><i class="fa fa-pencil "></i></button>
                          </form>
                        </span>
                        <h3 class="timeline-header"><a href="#"><?php echo $dados_etapa[1] ?></a> <?php echo $dados[$i]["descricao_etapa"] ?></h3>
                      </div>
                    </div>
                  <?php  ?>
                <?php } ?>
              <?php if (!$finalizado) { ?>
                <div class="time-label">
                  <span class="bg-gray">Adicionar Conclusão de Etapa</span>
                </div>
                <div>
                  <i class="fa fa-search bg-gray"></i>
                  <div class="timeline-item">
                    <span class="time">
                      <form action="novo-status.php?id=<?php echo $id_manutencao ?>" method="post" class="d-inline">
                        <button class="btn btn-success btn-xs" value="Enviar" name="Enviar"><i class="fa fa-plus"></i></button>
                      </form>
                    </span>
                    <h3 class="timeline-header no-border"><a href="#">Etapa</a> Adicione uma breve descrição para uma nova etapa concluída</h3>
                  </div>
                </div>
              <?php } ?>
              <div>
                <i class="fa fa-clock bg-gray"></i>
              </div>
              <div id="observacoes" class="my-5 px-4 py-5" style="color: #495057;">
                <span class="d-flex align-items-center mb-3"><i class="fa fa-info-circle" style="color: #495057; font-size: 20px; margin-right: 8px;"></i> <h4 class="m-0">Detalhes da manutenção:</h4></span>
                <p style="margin-left: 26px;"><?php echo $dados[0]["descricao"] ?></p>
              </div>
            </div>
          </div>
          <!-- /.col -->
        </div>
      </div>
      <!-- /.timeline -->

    </section>
    <!-- /.content -->
    </div>

  <!-- /.content-wrapper -->
  </section>
</section>

  <!--footer start-->
  <footer class="site-footer" id="footer-cadastro">
    <div class="text-center">
      <p>
        &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
      </p>
      <div class="credits">
       
       Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
      </div>
      <a href="historico" class="go-top">
        <i class="fa fa-angle-up"></i>
        </a>
    </div>
  </footer>
  <!--footer end-->

</section>

<!-- jQuery -->
<script src="../../../res/lib/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
<script src="../../../res/lib/jquery.scrollTo.min.js"></script>
<script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="../../../res/lib/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../../res/lib/demo.js"></script>
<!--common script for all pages-->
<script src="../../../res/lib/common-scripts.js"></script>

</body>
</html>
