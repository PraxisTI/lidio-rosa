<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../');
  }

  if((empty($_SESSION["msg"]) && (empty($_GET) || empty($_POST)))) {
    header('Location: ./');
  }

  if(!empty($_SESSION["msg"])) {
    unset($_SESSION["msg"]);
  }

  $id = $_GET['id_etapa'];

  include_once '../../../php/init.php';

  $PDO = db_connect();
  $sql = 'SELECT *, TIME_FORMAT(hora, \'%H:%i\'), DATE_FORMAT(dia, \'%d/%m/%Y\') FROM status WHERE id=:id';
  $stmt = $PDO -> prepare($sql);
  $stmt -> bindParam(':id', $id);
  $stmt -> execute();
  
  $dados = $stmt->fetch();

  setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/my-style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered"><?php echo $_SESSION["nome"] ?></h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        <!--main content start-->

        <!-- Content Wrapper. Contains page content -->
        <section id="main-content">
            <section class="wrapper site-min-height" style="min-height: 87vh;">

                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col-sm-6 offset-sm-2">
                                <h3><i class="fa fa-angle-right"></i> Status da manutenção
                            </div>
                            <div class="col-sm-4">
                                <ol class="breadcrumb float-sm-right">
                                    <li class="breadcrumb-item"><a href="../">Início</a></li>
                                    <li class="breadcrumb-item active">Timeline</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /.container-fluid -->
                </section>


                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <?php
                                    if(!empty($_SESSION["msg"])) {
                                        echo $_SESSION["msg"];
                                        unset($_SESSION["msg"]);
                                    }
                                ?>
                                <form method="POST" action="update-etapa.php?id_etapa=<?php echo $_GET["id_etapa"] ?>">
                                    <input type="hidden" name="id" value="<?php echo $_GET["id_etapa"] ?>">
                                    <input type="hidden" name="id_manutencao" value="<?php echo $_POST["id_manutencao"] ?>">
                                    <?php if($dados["etapa"] == 1) { ?>
                                        <input type="hidden" name="etapa" value="1">
                                    <?php }?>
                                    <div class="form-group w-70 px-sm-5">
                                        <label class="">Etapa*</label>
                                        <div class="">
                                            <select name="etapa" id="select-etapa" class="form-control" required <?php if($dados["etapa"] == 1) {echo "disabled";}?> >
                                                <option value="">Selecionar etapa...</option>
                                                <option value="1">Chegada</option>
                                                <option value="2">Análise</option>
                                                <option value="3">Diagnóstico</option>
                                                <option value="4">Elevador</option>
                                                <option value="7">Espera</option>
                                                <option value="5">Andamento</option>
                                                <option value="6">Finalizando</option>
                                                <option value="8">Pronto</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group w-70 px-sm-5 row">
                                        <div class="col-12 p-0 pr-md-2 col-md-6">
                                            <label class="">Dia*</label>
                                            <div class="">
                                                <input type="text" onkeypress="mascaraData(this)" onkeyup="mascData(this)" maxlength="10" value="<?php echo $dados["DATE_FORMAT(dia, '%d/%m/%Y')"]?>" pattern="(([0-9]{2}/){2}[0-9]{4})" name="dia" id="dia" class="form-control"
                                                    required placeholder="01/01/2020">
                                            </div>
                                        </div>
                                        <div class="col-12 p-0 pl-md-2 col-md-6">
                                            <label class="">Horário*</label>
                                            <div class="">
                                                <input type="text" maxlength="5" onkeyup="masc(this)" onkeypress="mascaraHora(this)" value="<?php echo $dados["TIME_FORMAT(hora, '%H:%i')"] ?>" pattern="([0-9]{2}:[0-9]{2})" name="hora" id="hora" class="form-control"
                                                    required placeholder="09:00">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group w-70 px-sm-5">
                                        <label class="">Descrição da etapa*</label>
                                        <div class="">
                                            <textarea name="descricao_etapa" style="resize: none;" id="descricao_etapa" rows="3" class="form-control" required><?php echo $dados["descricao_etapa"]?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group w-70 px-sm-5 mt-5">
                                        <div class="d-flex justify-content-center">
                                            <button class="btn btn-theme mr-2" id="btn-salvar" type="submit" name="submit"
                                                value="Enviar">Salvar</button>
                                            <button class="btn btn-theme04 ml-2" type="button"
                                                onclick="location.href = 'timeline.php?id=<?php echo $_POST['id_manutencao']?>'">Cancelar</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </section>

            <!--footer start-->
            <footer class="site-footer" id="footer-cadastro" style="bottom:0;">
                <div class="text-center">
                    <p>
                        &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                    </p>
                    <div class="credits">

                        Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                    </div>
                    <a href="historico" class="go-top">
                        <i class="fa fa-angle-up"></i>
                    </a>
                </div>
            </footer>
            <!--footer end-->

        </section>

        <!-- jQuery -->
        <script src="../../../res/lib/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
        <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
        <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
        <!-- AdminLTE App -->
        <script src="../../../res/lib/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="../../../res/lib/demo.js"></script>
        <!--common script for all pages-->
        <script src="../../../res/lib/common-scripts.js"></script>
        <script>
            document.querySelector('#select-etapa').value = <?php echo $dados["etapa"] ?>;
            
            const select = document.querySelector('#select-etapa');
            // const descricao = document.querySelector('#descricao_etapa');
            // console.log(descricao.value)
            select.addEventListener("change", verificarSelect);
            function verificarSelect(evt) {
                const etapa = evt.target.value;
                console.log(etapa);
                switch (etapa) {
                    case '1':
                        document.querySelector('#descricao_etapa').textContent = "Seu veículo foi estacionado na loja"
                        break;

                    case '2':
                        document.querySelector('#descricao_etapa').textContent = "Seu veículo está em análise pela nossa equipe"
                        break;

                    case '3':
                        document.querySelector('#descricao_etapa').textContent = "Foi diagnosticado reparos a serem feitos"
                        break;

                    case '4':
                        document.querySelector('#descricao_etapa').textContent = "Seu veículo já está no elevador para reparos"
                        break;
                
                    case '5':
                        document.querySelector('#descricao_etapa').textContent = "Nossa equipe está dedicada para o conserto"
                        break;

                    case '6':
                        document.querySelector('#descricao_etapa').textContent = "Estamos dando os toques finais"
                        break;

                    case '7':
                        document.querySelector('#descricao_etapa').textContent = "Aguardando peça ser entregue"
                        break;
                    
                    case '8':
                        document.querySelector('#descricao_etapa').textContent = "Já pode buscar o seu carro"
                        break;
                }

            }
                
            var sizeHora = 0;
            var sizeData = 0;
            
            function mascaraHora(e) {
                console.log(e.value.length);
                if(e.value.length==2 && sizeHora < e.value.length){
                    e.value += ':'
                }

                
                sizeHora = e.value.length
            }

            function masc(e) {
                if(e.value.length == 0) {
                    document.querySelector('#btn-salvar').disabled = false
                        e.style.borderColor = '#ccc';
                }
                if(e.value.length == 5) {
                    if((e.value.split(":", 2)[0] >= 24) || (e.value.split(":", 2)[1] >= 60)) {
                        document.querySelector('#btn-salvar').disabled = true
                        e.style.borderColor = 'red';
                    } else {
                        document.querySelector('#btn-salvar').disabled = false
                        e.style.borderColor = 'green';
                    }
                }
            }

            function mascaraData(e) {
                console.log(e.value.length);
                if((e.value.length==2 || e.value.length==5 )&& sizeData < e.value.length){
                    e.value += '/'
                }

                
                sizeData = e.value.length
            }

            function mascData(e) {
                if(e.value.length == 0) {
                    document.querySelector('#btn-salvar').disabled = false
                        e.style.borderColor = '#ccc';
                }
                if(e.value.length == 10) {
                    if((e.value.split("/", 2)[0] > 31) || (e.value.split("/", 2)[1] > 12)) {
                        document.querySelector('#btn-salvar').disabled = true
                        e.style.borderColor = 'red';
                    } else {
                        document.querySelector('#btn-salvar').disabled = false
                        e.style.borderColor = 'green';
                    }
                }
            }

        </script>

</body>

</html>