<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../');
  }

  if(empty($_GET) || empty($_POST)) {
    header('Location: ./');
  }

  var_dump($_POST);
  echo '<br>';
  var_dump($_GET);
  
  date_default_timezone_set('America/Sao_Paulo');
  $dia = date('Y-m-d');

  $hora = date('H:i');

  include_once '../../../php/init.php';

  $PDO = db_connect();
  $sql = 'INSERT INTO status(id_manutencao, etapa, hora, dia) VALUES (:id_manutencao, :etapa, :hora, :dia)';
  $stmt = $PDO -> prepare($sql);
  $stmt -> bindParam(':id_manutencao', $_GET["id"]);
  $stmt -> bindParam(':etapa', $_POST["etapa"]);
  $stmt -> bindParam(':hora', $hora);
  $stmt -> bindParam(':dia', $dia);
  if($stmt -> execute()) {
    $_SESSION["msg"] = "<p style='color: green; text-align: center'>Status da manutenção atualizado com sucesso!</p>";
  } else {
    $_SESSION["msg"] = "<p style='color: red; text-align: center'>Erro ao atualizar status da manutenção.</p>";
  }

  header('Location: timeline.php?id='.$_GET["id"]);