<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../../');
  }

  date_default_timezone_set('America/Sao_Paulo');
  $today = date("Y-m-d"); 
  $hoje = date("d.m.Y"); 
  $senha = 'lidiorosa123';

  include_once '../../../php/init.php';

  $PDO = db_connect();
  
  $sql = 'SELECT marca FROM marcas';
  $stmt = $PDO -> prepare($sql);
  $stmt -> execute();
  $marcas = array();
  
  while ($marca = $stmt -> fetch()) {
    array_push($marcas, $marca['marca']);
  }

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">

    <link rel="stylesheet" href="../../../res/css/my-style.css">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
    TOP BAR CONTENT & NOTIFICATIONS
    *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="../index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
    MAIN SIDEBAR MENU
    *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered">
                        <?php echo $_SESSION["nome"] ?>
                    </h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
    MAIN CONTENT
    *********************************************************************************************************************************************************** -->
        <!--main content start-->

        <!-- Content Wrapper. Contains page content -->
        <section id="main-content">
            <section class="wrapper-1 ">

                <div class="col-lg-12">
                    <!-- Content Header (Page header) -->
                    <section class="content-header">
                        <div class="container-fluid">
                            <div class="row mb-2">
                                <div class="col-sm-6">
                                    <h3><i class="fa fa-angle-right"></i> Cadastrar Cliente
                                </div>
                                <div class="col-sm-6">
                                    <ol class="breadcrumb float-sm-right">
                                        <li class="breadcrumb-item"><a href="../index.php">Início</a></li>
                                        <li class="breadcrumb-item active">Painel de Controle</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <!-- /.container-fluid -->
                    </section>

                    <!-- Main content -->
                    <section class="content">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12">
                                    <h4 class="mb" id="titulo"> Informações do Cliente</h4>
                                    <?php
                                        if(!empty($_SESSION["msg"])) {
                                            echo $_SESSION["msg"];
                                            unset($_SESSION["msg"]);
                                        }
                                    ?>
                                    <form method="POST" action="add-cliente.php" enctype="multipart/form-data">
                                        <div class="w-70 justify-content-center row">
                                            <input type="hidden" name="data_chegada" value="<?php echo $today ?>">
                                            <div class="form-group col-12 col-md-7 p-0 pr-md-2">
                                                <label class="">Nome* <small>(até 100 caracteres)</small></label>
                                                <div class="">
                                                    <input type="text" name="proprietario" id="proprietario" class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-5 p-0 pl-md-2">
                                                <label class="">Profissão</label>
                                                <div class="">
                                                    <input type="text" name="profissao" id="profissao" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="w-70 justify-content-center row">
                                            <div class="form-group col-12 col-md-4 p-0 pr-md-2">
                                                <label class="">Telefone Residencial</label>
                                                <div class="">
                                                    <input type="text" pattern="([\(][0-9]{2}[\)][\ ]?[0-9]{4,5}[\-][0-9]{4})" placeholder="(99) 99999-9999" name="tel_residencial" id="tel_residencial" class="form-control" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);">
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-4 p-0 px-md-2">
                                                <label class="">Telefone de Trabalho</label>
                                                <div class="">
                                                    <input type="text" pattern="([\(][0-9]{2}[\)][\ ]?[0-9]{4,5}[\-][0-9]{4})" placeholder="(99) 99999-9999" name="tel_trabalho" id="tel_trabalho" class="form-control" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);">
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-4 p-0 pl-md-2">
                                                <label class="">Telefone Celular</label>
                                                <div class="">
                                                    <input type="text" pattern="([\(][0-9]{2}[\)][\ ]?[0-9]{4,5}[\-][0-9]{4})" placeholder="(99) 99999-9999" name="tel_celular" id="tel_celular" class="form-control" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="w-70 justify-content-center row">
                                            <div class="form-group col-12 col-md-4 p-0 pr-md-2">
                                                <label class="">E-mail</label>
                                                <div class="">
                                                    <input type="email" name="email" id="email" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-3 p-0 px-md-2">
                                                <label class="">CPF</label>
                                                <div class="">
                                                    <input type="text" name="cpf" id="cpf" onkeyup="cpfCheck(this)" maxlength="14" onkeydown="javascript: fMasc( this, mCPF );" placeholder="000.000.000-00" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-5 p-0 pl-md-2" id="file-upload">
                                                <label for="">Foto de perfil</label>
                                                <input type="file" name="foto_user" id="foto_user">
                                            </div>
                                        </div>
                                        <div class="w-70 justify-content-center row">
                                            <div class="form-group col-12 col-md-5 p-0 pr-md-2">
                                                <label class="">Endereço</label>
                                                <div class="">
                                                    <input type="text" name="endereco" id="endereco" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-4 p-0 px-md-2">
                                                <label class="">Bairro</label>
                                                <div class="">
                                                    <input type="text" name="bairro" id="bairro" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-12 col-md-3 p-0 pl-md-2">
                                                <label class="">CEP</label>
                                                <div class="">
                                                    <input type="text" name="cep" id="cep" class="form-control">
                                                </div>
                                            </div>
                                        </div>                                            
                                        
                                        <div class="w-70 row justify-content-center">
                                            <div class="col-12 col-md-6 p-0 pr-2">
                                                <div class="d-flex flex-column">
                                                    <div class="form-group">
                                                        <label class="">Placa*</label>
                                                        <div class="">
                                                            <input title="Formatos permitidos ABC1234, ABC1D23" pattern="([A-Za-z]{3}(([0-9]{4})|([0-9]{1}[A-Za-z]{1}[0-9]{2})))" type="text" name="placa" id="placa" class="form-control" required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="">Modelo*</label>
                                                        <div class="">
                                                            <input type="text" name="modelo" id="modelo" class="form-control" required>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="">Marca*</label>
                                                        <div class="">
                                                            <select name="marca" id="marca" class="form-control">
                                                                <option value="">--</option>
                                                                <?php for ($i=0; $i < count($marcas); $i++) { ?>
                                                                    <option value="<?php echo $marcas[$i] ?>"><?php echo $marcas[$i] ?></option>                                                                
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="">Ano*</label>
                                                        <div class="">
                                                            <input type="text" title="Formatos permitidos 20, 2020, 2019/20, 2019/2020" name="ano" pattern="(([0-9]{2})|([0-9]{4}\/[0-9]{4})|([0-9]{4}\/[0-9]{2})|([0-9]{4}))" id="ano" class="form-control" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6 p-0 pl-2 pb-3">
                                                <div class="d-flex flex-column">
                                                    <div class="form-group">
                                                        <label class="">Informações do cliente</label>
                                                        <div class="">
                                                            <textarea class="form-control" id="info_proprietario" name="info_proprietario" style="resize: none; height: 106px"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="">Descrição do veículo</label>
                                                        <div class="">
                                                            <textarea class="form-control" id="info_carro" name="info_carro" style="resize: none; height: 106px"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group w-70 mt-5">
                                            <div class="d-flex justify-content-center">
                                                <button class="btn btn-theme mr-2" type="submit" name="submit" id="btn-salvar" value="Enviar">Salvar</button>
                                                <button class="btn btn-theme04 ml-2" type="button" onclick = "location.href = '../painel-de-controle.php'">Cancelar</button>
                                            </div>
                                        </div>
                                        
                                    </form>
                                    <div class="w-70 form-group">
                                        <p>Obs.: 
                                        <br>A data de chegada do cliente será cadastrada automaticamente com o dia de hoje (<?php echo $hoje?>)
                                        <br>A senha do cliente é por padrão "<?php echo $senha ?>"
                                        </p>
                                    </div>
                                </div>
                            <!-- /col-lg-8 -->
                            </div>
                            <!-- /row -->
                           
                        </div>

                    </section>
                    <!-- /.content -->
                </div>

                <!-- /.content-wrapper -->
            </section>
        </section>

        <!--footer start-->
        <footer class="site-footer" id="footer-cadastro">
            <div class="text-center">
                <p>
                    &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                </p>
                <div class="credits">

                    Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                </div>
                <a href="./" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->

    </section>

    <!-- jQuery -->
    <script src="../../../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../../../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../../../res/lib/common-scripts.js"></script>
<script>
    function mask(o, f) {
        setTimeout(function() {
            var v = mphone(o.value);
            if (v != o.value) {
                o.value = v;
            }
        }, 1);
    }

    function mphone(v) {
        var r = v.replace(/\D/g, "");
        r = r.replace(/^0/, "");
        if (r.length > 10) {
            r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
        } else if (r.length > 5) {
            r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
        } else if (r.length > 2) {
            r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
        } else {
            r = r.replace(/^(\d*)/, "($1");
        }
        return r;
    }

    function is_cpf (c) {
        if((c = c.replace(/[^\d]/g,"")).length != 11)
            return false
        if (c == "00000000000")
            return false;
        var r;
        var s = 0;
        for (i=1; i<=9; i++)
            s = s + parseInt(c[i-1]) * (11 - i);
        r = (s * 10) % 11;
        if ((r == 10) || (r == 11))
            r = 0;
        if (r != parseInt(c[9]))
            return false;
        s = 0;
        for (i = 1; i <= 10; i++)
            s = s + parseInt(c[i-1]) * (12 - i);
        r = (s * 10) % 11;
        if ((r == 10) || (r == 11))
            r = 0;
        if (r != parseInt(c[10]))
            return false;
        return true;
    }

    function fMasc(objeto,mascara) {
        obj=objeto
        masc=mascara
        setTimeout("fMascEx()",1)
    }

    function fMascEx() {
        obj.value=masc(obj.value)
    }

    function mCPF(cpf){
        cpf=cpf.replace(/\D/g,"")
        cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2")
        cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2")
        cpf=cpf.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
        return cpf
    }

    cpfCheck = function (el) {
        document.getElementById('cpf').style.borderColor = is_cpf(el.value)? 'green' : 'red';
        document.getElementById('btn-salvar').disabled = is_cpf(el.value)? false : true;
        if(el.value=='') {
            document.getElementById('cpf').style.borderColor = '#ccc';
            document.getElementById('btn-salvar').disabled = false;
        }
    }
    
    </script>
</body>

</html>