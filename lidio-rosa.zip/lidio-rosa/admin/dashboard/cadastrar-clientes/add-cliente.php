<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }
    
    var_dump($_POST);

    $placa = strtoupper($_POST["placa"]);
    $email = strtolower($_POST["email"]);
    $diretorio ='../../../res/img/users_img/';
    $foto_user = $_FILES["foto_user"]["name"];
    
    $aux = explode(".", $foto_user);
    $extension=end($aux);

    $foto = $placa.".".$extension;

    if(empty($_FILES["foto_user"]["name"])){
        $sql = 'INSERT INTO carros(placa, marca, modelo, ano, proprietario, profissao, cpf, info_proprietario, info_carro, telefone_residencial, telefone_trabalho, telefone_celular, endereco, bairro, cep, email, data_chegada) VALUES (:placa, :marca, :modelo, :ano, :proprietario, :profissao, :cpf, :info_proprietario, :info_carro, :telefone_residencial, :telefone_trabalho, :telefone_celular, :endereco, :bairro, :cep, :email, :data_chegada)';
    } else {
        $sql = 'INSERT INTO carros(placa, marca, modelo, ano, proprietario, profissao, cpf, info_proprietario, info_carro, telefone_residencial, telefone_trabalho, telefone_celular, endereco, bairro, cep, email, data_chegada, foto_user) VALUES (:placa, :marca, :modelo, :ano, :proprietario, :profissao, :cpf, :info_proprietario, :info_carro, :telefone_residencial, :telefone_trabalho, :telefone_celular, :endereco, :bairro, :cep, :email, :data_chegada, :foto_user)';
        if(!move_uploaded_file($_FILES['foto_user']['tmp_name'], $diretorio.$foto)){
            $_SESSION["msg"] = "<p style='color: red; text-align: center'>Erro ao salvar foto. Cliente não cadastrado.</p>";
            header('Location: ./');
        }
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $placa);
    $stmt -> bindParam(':marca', $_POST["marca"]);
    $stmt -> bindParam(':modelo', $_POST["modelo"]);
    $stmt -> bindParam(':ano', $_POST["ano"]);
    $stmt -> bindParam(':proprietario', $_POST["proprietario"]);
    $stmt -> bindParam(':profissao', $_POST["profissao"]);
    $stmt -> bindParam(':cpf', $_POST["cpf"]);
    $stmt -> bindParam(':info_proprietario', $_POST["info_proprietario"]);
    $stmt -> bindParam(':info_carro', $_POST["info_carro"]);
    $stmt -> bindParam(':telefone_residencial', $_POST["tel_residencial"]);
    $stmt -> bindParam(':telefone_trabalho', $_POST["tel_trabalho"]);
    $stmt -> bindParam(':telefone_celular', $_POST["tel_celular"]);
    $stmt -> bindParam(':endereco', $_POST["endereco"]);
    $stmt -> bindParam(':bairro', $_POST["bairro"]);
    $stmt -> bindParam(':cep', $_POST["cep"]);
    $stmt -> bindParam(':email', $email);
    $stmt -> bindParam(':data_chegada', $_POST["data_chegada"]);
    if(!empty($_FILES["foto_user"]["name"])){
        $stmt -> bindParam(':foto_user', $foto);
    }
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Cliente cadastrado com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível cadastrar o cliente.<br>Tente novamente.</p>";
        if(!empty($_FILES["foto_user"]["name"])){
            unlink($diretorio.$foto);
        }
    }

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";
    echo "<script>location.href='./'</script>";