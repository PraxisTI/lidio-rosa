<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }
    
    switch ($_POST["permissao"]) {
        case '1':
            $permissao = true;
            break;
        
        default:
            $permissao = false;
            break;
    }


    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'UPDATE administradores SET email=:email, senha=:senha, nome=:nome,permissao=:permissao WHERE id = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':email', $_POST["email"]);
    $stmt -> bindParam(':senha', $_POST["nova_senha"]);
    $stmt -> bindParam(':nome', $_POST["nome"]);
    $stmt -> bindParam(':id', $_POST["id"]);
    $stmt -> bindParam(':permissao', $permissao);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Administrador atualizado com sucesso!</p>";
        if($_SESSION["admin_id"] == $_POST["id"]) {
            $_SESSION["nome"] = $_POST["nome"];
            $_SESSION["permissao"] = $_POST["permissao"];
        }
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível atualizar o administrador.<br>Tente novamente.</p>";
    }

    header('Location: ./');