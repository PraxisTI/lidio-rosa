<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }
    
    switch ($_POST["permissao"]) {
        case '1':
            $permissao = true;
            break;
        
        default:
            $permissao = false;
            break;
    }

    $email = strtolower ($_POST["email"]);

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'INSERT INTO administradores (email, senha, nome, permissao) VALUES (:email, :senha, :nome, :permissao)';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':email', $email);
    $stmt -> bindParam(':senha', $_POST["senha"]);
    $stmt -> bindParam(':nome', $_POST["nome"]);
    $stmt -> bindParam(':permissao', $permissao);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Administrador cadastrado com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível cadastrar o administrador.<br>Tente novamente.</p>";
    }

    header('Location: ./');