<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }

    $placa = $_GET["placa"];

    $foto = "../../../res/img/users_img/".$_POST["foto"];

    $foto_padrao = "../../../res/img/users_img/user.png";

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'DELETE FROM carros WHERE placa = :placa';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $placa);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Cliente excluído com sucesso!</p>";
        if($foto != $foto_padrao){
            unlink($foto);
        }
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível excluir o cliente.<br>Tente novamente.</p>";
    }

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";
    echo "<script>location.href='./'</script>";