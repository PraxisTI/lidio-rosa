<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }
    
    $placa = $_POST["placa"];
    $email = strtolower($_POST["email"]);
    $diretorio ='../../../res/img/users_img/';
    $foto_user = $_FILES["foto_user"]["name"];

    $aux = explode(".", $foto_user);
    $extension=end($aux);

    $foto = $placa.".".$extension;

    if(empty($_FILES["foto_user"]["name"])){
        if(empty($_POST["senha"])) {
            $sql = 'UPDATE carros SET proprietario=:proprietario, placa =:placa, marca=:marca, modelo=:modelo, ano=:ano, profissao=:profissao, cpf=:cpf, info_proprietario=:info_proprietario, info_carro=:info_carro, telefone_residencial=:telefone_residencial, telefone_trabalho=:telefone_trabalho, telefone_celular=:telefone_celular, endereco=:endereco, bairro=:bairro, cep=:cep, email=:email WHERE placa=:placa_antiga';
        } else {
            $sql = 'UPDATE carros SET proprietario=:proprietario, placa =:placa, marca=:marca, modelo=:modelo, ano=:ano, profissao=:profissao, cpf=:cpf, info_proprietario=:info_proprietario, info_carro=:info_carro, telefone_residencial=:telefone_residencial, telefone_trabalho=:telefone_trabalho, telefone_celular=:telefone_celular, endereco=:endereco, bairro=:bairro, cep=:cep, email=:email, senha=:senha WHERE placa=:placa_antiga';
        }
    } else {
        if(empty($_POST["senha"])) {
            $sql = 'UPDATE carros SET proprietario=:proprietario, placa =:placa, marca=:marca, modelo=:modelo, ano=:ano, profissao=:profissao, cpf=:cpf, info_proprietario=:info_proprietario, info_carro=:info_carro, telefone_residencial=:telefone_residencial, telefone_trabalho=:telefone_trabalho, telefone_celular=:telefone_celular, endereco=:endereco, bairro=:bairro, cep=:cep, email=:email, foto_user=:foto_user WHERE placa=:placa_antiga';
        } else {
            $sql = 'UPDATE carros SET proprietario=:proprietario, placa =:placa, marca=:marca, modelo=:modelo, ano=:ano, profissao=:profissao, cpf=:cpf, info_proprietario=:info_proprietario, info_carro=:info_carro, telefone_residencial=:telefone_residencial, telefone_trabalho=:telefone_trabalho, telefone_celular=:telefone_celular, endereco=:endereco, bairro=:bairro, cep=:cep, email=:email, senha=:senha, foto_user=:foto_user WHERE placa=:placa_antiga';
        }
        if($_POST["foto_antiga"] != "user.png") {
            unlink($diretorio.$_POST["foto_antiga"]);
        }
        if(!move_uploaded_file($_FILES['foto_user']['tmp_name'], $diretorio.$foto)){
            $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível cadastrar foto os dados. Tente novamente.</p>";
            header('Location: ./');
        }
    }  
    
    include_once '../../../php/init.php';
    
    $PDO = db_connect();

    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $placa);
    $stmt -> bindParam(':placa_antiga', $_POST["placa_antiga"]);
    $stmt -> bindParam(':marca', $_POST["marca"]);
    $stmt -> bindParam(':modelo', $_POST["modelo"]);
    $stmt -> bindParam(':ano', $_POST["ano"]);
    $stmt -> bindParam(':proprietario', $_POST["proprietario"]);
    $stmt -> bindParam(':profissao', $_POST["profissao"]);
    $stmt -> bindParam(':cpf', $_POST["cpf"]);
    $stmt -> bindParam(':info_proprietario', $_POST["info_proprietario"]);
    $stmt -> bindParam(':info_carro', $_POST["info_carro"]);
    $stmt -> bindParam(':telefone_residencial', $_POST["tel_residencial"]);
    $stmt -> bindParam(':telefone_trabalho', $_POST["tel_trabalho"]);
    $stmt -> bindParam(':telefone_celular', $_POST["tel_celular"]);
    $stmt -> bindParam(':endereco', $_POST["endereco"]);
    $stmt -> bindParam(':bairro', $_POST["bairro"]);
    $stmt -> bindParam(':cep', $_POST["cep"]);
    $stmt -> bindParam(':email', $email);
    if(!empty($_POST["senha"])) {
        $stmt -> bindParam(':senha', $_POST["senha"]);
    }
    if(!empty($_FILES["foto_user"]["name"])){
        $stmt -> bindParam(':foto_user', $foto);
    }
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Dados atualizados com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível atualizar os dados. Tente novamente.</p>";
        if(!empty($_FILES["foto_user"]["name"])){
            unlink($diretorio.$foto);
        }
    }

    header('Location: ./');  