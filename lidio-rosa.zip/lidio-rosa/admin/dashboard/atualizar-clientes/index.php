<?php
  session_start();
  if (!$_SESSION["auth_admin"]) {
    header('Location: ../../');
  }

  $total_reg = "25";

  if (empty($_GET["pagina"])) {
    $pagina = 1;
    $pc = 1;
  } else {
    $pagina = $_GET['pagina'];
    $pc = $pagina;
  }
    
  $inicio = $pc - 1;
  $inicio = $inicio * $total_reg;

  include_once '../../../php/init.php';

  $PDO = db_connect();
  $sql = "SELECT *, DATE_FORMAT(data_chegada, \"%d\.%m\.%Y\") FROM carros ORDER BY proprietario ASC LIMIT $inicio, $total_reg";
  $stmt = $PDO -> prepare($sql);
  $stmt -> execute();

  $PDO2 = db_connect();
  $sql2 = "SELECT *, DATE_FORMAT(data_chegada, \"%d\.%m\.%Y\") FROM carros ORDER BY proprietario ASC";
  $stmt2 = $PDO2 -> prepare($sql2);
  $stmt2 -> execute();

  $dados_total = $stmt2 -> fetchAll();
  $qtd = count($dados_total);

  $tp = number_format(ceil($qtd / $total_reg));
  if($tp == 0) {
    $tp = 1;
  }
  $qtd_da_pagina = 0;

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">

    <link rel="stylesheet" href="../../../res/css/my-style.css">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
    TOP BAR CONTENT & NOTIFICATIONS
    *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="../" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
    MAIN SIDEBAR MENU
    *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered">
                        <?php echo $_SESSION["nome"] ?>
                    </h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
    MAIN CONTENT
    *********************************************************************************************************************************************************** -->
        <!--main content start-->

        <!-- Content Wrapper. Contains page content -->
        <section id="main-content">
            <section class="wrapper ">
                <h3><i class="fa fa-angle-right"></i> Atualizar Clientes</h3>    
                <?php
                    if(!empty($_SESSION["msg"])) {
                        echo $_SESSION["msg"];
                        unset($_SESSION["msg"]);
                    }
                ?>
                <div class="row mt">
                    <div class="col-md-12">
                        <div class="content-panel">
                        <table class="table table-striped table-advance table-hover" id="dados">
                            <div style="display: flex; justify-content: space-between;">
                                <div>
                                    <h4><i class="fa fa-angle-right"></i> Clientes</h4>
                                    <span id="pg" style="margin-left: 10px; font-size: 15px;">Página <?php echo($pc." de ".$tp)?> <small id="registros-qtd">(25 registros)</small></span>                                    
                                </div>
                                <div style="margin-right: 10px; margin-top: auto;">
                                    <i class="fa fa-search" style="margin-right: 10px; font-size: 15px;"></i> <input onkeyup="reset()" style="font-size: 15px; padding: 3px 8px;" placeholder="Buscar placa" type="text" name="search" id="search">
                                </div>
                            </div>
                            <hr>
                            <thead>
                                <tr>
                                    <th><i class="fa fa-bullhorn"></i> Nome</th>
                                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Profissão</th>
                                    <th><i class="fa fa-bookmark"></i> Placa</th>
                                    <th><i class="fa fa-car"></i> Carro</th>
                                    <th><i class="fa fa-calendar-check-o"></i> Data de chegada</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    while ($dados = $stmt -> fetch()) {
                                        $qtd_da_pagina++;
                                        $link = "profile.php?page=lista-cliente&placa=".$dados["placa"];
                                        $data = $dados["DATE_FORMAT(data_chegada, \"%d\.%m\.%Y\")"];
                                ?>
                                <tr>
                                    <td><?php echo $dados["proprietario"]?></td>
                                    <td class="hidden-phone"><?php echo empty($dados["profissao"])?"Não informado":$dados["profissao"] ?></td>
                                    <td id="placa"><?php echo $dados["placa"]?></td>
                                    <td><?php echo $dados["marca"]." ".$dados["modelo"]."-".$dados["ano"] ?></td>
                                    <td><?php echo $data?></td>
                                    <td>
                                        <form action="<?php echo $link ?>" method="POST">
                                            <button class="btn btn-primary btn-xs" title="Clique para editar" name="submit" value="Enviar"><i class="fa fa-pencil"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                        <table style="display: none;" class="table table-striped table-advance table-hover" id="dados-2">
                            <thead>
                                <tr>
                                    <th><i class="fa fa-bullhorn"></i> Nome</th>
                                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Profissão</th>
                                    <th><i class="fa fa-bookmark"></i> Placa</th>
                                    <th><i class="fa fa-car"></i> Carro</th>
                                    <th><i class="fa fa-calendar-check-o"></i> Data de chegada</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php for($j = 0; $j < $qtd; $j++) { 
                                $link = "profile.php?page=lista-cliente&placa=".$dados_total[$j]["placa"];
                                $data = $dados_total[$j]["DATE_FORMAT(data_chegada, \"%d\.%m\.%Y\")"];
                            ?>
                                <tr>
                                    <td><?php echo $dados_total[$j]["proprietario"] ?></td>
                                    <td class="hidden-phone"><?php echo empty($dados_total[$j]["profissao"])?"Não informado":$dados_total[$j]["profissao"] ?></td>
                                    <td id="placa-2"><?php echo $dados_total[$j]["placa"] ?></td>
                                    <td><?php echo $dados_total[$j]["marca"]." ".$dados_total[$j]["modelo"]."-".$dados_total[$j]["ano"] ?></td>
                                    <td><?php echo $data ?></td>
                                    <td>
                                        <form action="<?php echo $link ?>" method="POST">
                                        <button class="btn btn-primary btn-xs" title="Clique para editar" name="submit" value="Enviar"><i class="fa fa-pencil"></i></button>
                                    </form>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                        <div style="display: flex; justify-content: center;" id="paginas">
                            <?php if(($pc) > 3) {?>
                                <a href="index.php?pagina=<?php echo(1) ?>">Início</a><span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i> <?php echo (($pc - 12) > 1)?"<i class='fa fa-ellipsis-h' aria-hidden='true'></i>":"" ?></span> 
                            <?php } ?>
                            <?php if(($pc - 12) > 1) {?>
                                <a href="index.php?pagina=<?php echo($pc - 12) ?>"><?php echo($pc - 12) ?></a><span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></span>
                            <?php } ?>
                            <?php for ($i=2; $i > 0; $i--) { ?>
                                <?php if(($pc - $i) >= 1) {?>
                                    <a href="index.php?pagina=<?php echo($pc - $i) ?>" style="margin-right: 5px;"><?php echo($pc - $i) ?></a>
                                <?php } ?>
                            <?php } ?>
                                <a href="index.php?pagina=<?php echo($pc) ?>" style="font-weight: bold; text-decoration: underline;"><?php echo($pc) ?></a>
                            <?php for ($i=1; $i < 3; $i++) { ?>
                                <?php if($pc + $i <= $tp) {?>
                                    <a href="index.php?pagina=<?php echo($pc + $i) ?>" style="margin-left: 5px;"><?php echo ($pc + $i) ?></a>
                                <?php } ?>
                            <?php } ?>
                            <?php if($pc + 12 < $tp) {?>
                                <span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></span><a href="index.php?pagina=<?php echo($pc + 12) ?>"><?php echo($pc + 12) ?></a>
                            <?php } ?>
                            <?php if($pc < $tp - 2) {?>
                                <span style="margin: 0 15px;"><i class="fa fa-ellipsis-h" aria-hidden="true"></i> <?php echo (($pc + 12) < $tp)?"<i class='fa fa-ellipsis-h' aria-hidden='true'></i>":"" ?></span><a href="index.php?pagina=<?php echo($tp) ?>">Fim</a>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- /content-panel -->
                </div>
                <!-- /col-md-12 -->
                </div>
            </section>
        </section>

        <!--footer start-->
        <footer class="site-footer" id="footer-cadastro">
            <div class="text-center">
                <p>
                    &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                </p>
                <div class="credits">

                    Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                </div>
                <a href="./" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->

    </section>

    <!-- jQuery -->
    <script src="../../../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../../../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../../../res/lib/common-scripts.js"></script>
    <script>
        document.querySelector('#registros-qtd').textContent = "(<?php echo $qtd_da_pagina ?> registros)"

        document.getElementById('search').addEventListener('keyup', pesquisaTabela());

        function reset() {
            if(document.getElementById("search").value == "") {
                document.getElementById("dados").style.display="table";
                document.getElementById("dados-2").style.display="none";
                document.getElementById("paginas").style.display = "flex";  
                console.log("ola");
            } else {
                document.getElementById("dados-2").style.display="table";
                document.getElementById("dados").style.display="none";
                document.getElementById("paginas").style.display = "none";
                console.log("oi");
            }
        }

        window.onload = reset();

        function qtdRegistro() {
            var elem = document.querySelectorAll("table#dados-2 tbody tr")

            var count = 0;
            for(i = 0; i < elem.length; i++) {
                if(elem[i].style.display != "none"){
                    count++;
                }
            }
            console.log(count)
            
            if(document.getElementById("search").value.length > 0) {
                document.querySelector('#pg').innerHTML = "<small id='registros-qtd'>("+count+" registros)</small>"
            } else {
                document.querySelector('#pg').innerHTML = "Página <?php echo $pc ?> de <?php echo $tp ?> <small id='registros-qtd'>(<?php echo $qtd_da_pagina ?> registros)</small>"
            }
        }

        function pesquisaTabela() {
            var filter, table, tr, td, i;

            table = document.getElementById("dados-2");
            document.getElementById("dados-2").style.display = "table";
            document.getElementById("dados").style.display = "none";
            document.getElementById("paginas").style.display = "none";


            return function() {
                tr_placa = table.querySelectorAll("tbody tr #placa-2");
                tr = table.querySelectorAll("tbody tr");
                filter = this.value.toUpperCase();
                for (i = 0; i < tr.length; i++) {
                    var match = tr_placa[i].innerHTML.toUpperCase().indexOf(filter) > -1;
                    tr[i].style.display = match ? "table-row" : "none";
                }
                qtdRegistro()
            }
            
        }
    </script>

</body>

</html>