<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'SELECT *, c.placa, DATE_FORMAT(data_chegada, "%d\.%m\.%Y"), COUNT(id) AS qtdVisitas FROM carros AS c JOIN manutencoes AS m ON c.placa = m.placa AND c.placa = :placa';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':placa', $_GET["placa"]);
    $stmt -> execute();

    $dados = $stmt -> fetch();
    
    $data = $dados["DATE_FORMAT(data_chegada, \"%d\.%m\.%Y\")"];

    $foto = '../../../res/img/users_img/'.$dados["foto_user"];

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>LidioDash</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../res/css/all.min.css">
    <!-- AdminLTE css -->
    <link rel="stylesheet" href="../../../res/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Bootstrap core CSS -->
    <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!--external css-->
    <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../../../res/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="../../../res/lib/gritter/css/jquery.gritter.css" />
    <!-- Custom styles for this template -->
    <link href="../../../res/css/style.css" rel="stylesheet">
    <link href="../../../res/css/style-responsive.css" rel="stylesheet">

    <link rel="stylesheet" href="../../../res/css/my-style.css">
    <script src="../../../res/lib/chart-master/Chart.js"></script>
</head>

<body>
    <section id="container">
        <!-- **********************************************************************************************************************************************************
    TOP BAR CONTENT & NOTIFICATIONS
    *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="../index.php" class="logo"><b>LIDIO<span>DASH</span></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                    <!-- notification dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
                <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="../../../php/logout.php">Sair</a></li>
                </ul>
            </div>
            
        </header>
        <!--header end-->
        <!-- **********************************************************************************************************************************************************
    MAIN SIDEBAR MENU
    *********************************************************************************************************************************************************** -->
        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
                    <h5 class="centered">
                        <?php echo $_SESSION["nome"] ?>
                    </h5>
                    <li class="mt">
                        <a href="../">
                            <i class="fa fa-dashboard"></i>
                            <span>Lista de Contatos</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a class="active" href="../painel-de-controle.php">
                            <i class="fa fa-desktop"></i>
                            <span>Painel de Controle</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../historico">
                            <i class="fa fa-history"></i>
                            <span>Histórico</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../fornecedores">
                            <i class="fa fa-users"></i>
                            <span>Fornecedores</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../marcas">
                            <i class="fa fa-tags"></i>
                            <span>Marcas</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../servicos">
                            <i class="fa fa-wrench"></i>
                            <span>Serviços</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../estoque">
                            <i class="fa fa-cubes"></i>
                            <span>Estoque</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a href="../meus-dados">
                            <i class="fa fa-user"></i>
                            <span>Meus dados</span>
                        </a>
                    </li>
                </ul>
                <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->
        <!-- **********************************************************************************************************************************************************
    MAIN CONTENT
    *********************************************************************************************************************************************************** -->
        <!--main content start-->
        <section id="main-content">
            <section class="wrapper site-min-height">
                <div class="row mt">
                    <div class="col-lg-12 px-5">
                        <section class="content-header">
                            <div class="container-fluid">
                                <div class="row mb-2">
                                    <div class="col-sm-6">
                                        <h3><i class="fa fa-angle-right"></i> Atualizar Cliente
                                    </div>
                                    <div class="col-sm-6">
                                        <ol class="breadcrumb float-sm-right">
                                            <li class="breadcrumb-item"><a href="../index.php">Início</a></li>
                                            <li class="breadcrumb-item active">Painel de Controle</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                            <!-- /.container-fluid -->
                        </section>
                        <div class="row content-panel">
                            <div class="col-md-4 profile-text mt mb centered">
                                <div class="right-divider hidden-sm hidden-xs">
                                    <h4><?php echo $dados["placa"]?></h4>
                                    <h6>PLACA DO CARRO</h6>
                                    <h4><?php echo $data ?></h4>
                                    <h6>DATA DE CHEGADA</h6>
                                    <h4><?php echo $dados["qtdVisitas"] ?></h4>
                                    <h6>NÚMERO DE VISITAS A LOJA</h6>
                                </div>
                            </div>
                            <!-- /col-md-4 -->
                            <div class="col-md-4 profile-text">
                                <h3><?php echo $dados["proprietario"]?></h3>
                                <h6><?php echo (empty($dados["profissao"]))?"Não informado":$dados["profissao"] ?></h6>
                                <p><?php echo $dados["info_proprietario"]?></p>
                                <br>
                                <?php if(!empty($dados["email"]) && strpos($dados["email"], '@')) {?>
                                    <p><a href="mailto:<?php echo $dados["email"]?>" class="btn btn-theme"><i class="fa fa-envelope"></i> Enviar
                                        Mensagem</a></p>
                                <?php } else { ?>
                                    <p>E-mail não informado</p>
                                <?php } ?>
                            </div>
                            <!-- /col-md-4 -->
                            <div class="col-md-4 centered">
                                <div class="profile-pic">
                                    <p><img src="<?php echo $foto ?>" class="img-circle"></p>
                                </div>
                            </div>
                            <!-- /col-md-4 -->
                        </div>
                        <!-- /row -->
                    </div>

                    <div class="col-lg-12 mt">
                        <div class=" content-panel">
                            <!-- /tab-pane -->
                            <div id="edit" class="tab-pane">
                                <div class="row justify-content-center">
                                    <div class="col-lg-8 detailed">
                                        <h4 class="mb"> Informação de Perfil</h4>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Nome e Sobrenome</label>
                                            </div>
                                            <div class="col-6">
                                                <label
                                                    class="label-edit-info"><?php echo $dados["proprietario"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Profissão</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["profissao"])?"Não informado":$dados["profissao"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">CPF</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["cpf"])?"Não informado":$dados["cpf"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Descrição do veículo</label>
                                            </div>
                                            <div class="col-6">
                                                <label
                                                    class="label-edit-info"><?php echo $dados["placa"]." - ".$dados["marca"]." ".$dados["modelo"]."-".$dados["ano"] ?><br><?php echo $dados["info_carro"]?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-8 detailed mt">
                                        <h4 class="mb">Informação de Contato</h4>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Endereço</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["endereco"])?"Não informado":($dados["endereco"].', '.$dados["bairro"]) ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">CEP</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["cep"])?"Não informado":$dados["cep"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Telefone Residencial</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["telefone_residencial"])?"Não informado":$dados["telefone_residencial"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Telefone de Trabalho</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["telefone_trabalho"])?"Não informado":$dados["telefone_trabalho"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">Telefone de Celular</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["telefone_celular"])?"Não informado":$dados["telefone_celular"] ?></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-5  offset-1">
                                                <label class="control-label label-edit">E-mail</label>
                                            </div>
                                            <div class="col-6">
                                                <label class="label-edit-info"><?php echo empty($dados["email"])?"Não informado":$dados["email"] ?></label>
                                            </div>
                                        </div>
                                        <div class="form-group mt-5">
                                            <div class="d-flex justify-content-center">
                                                <form action="atualizar.php" method="post">
                                                    <input type="hidden" name="placa"
                                                        value="<?php echo $dados["placa"]?>">
                                                        <input type="hidden" name="qtdVisitas" value="<?php echo $dados["qtdVisitas"] ?>">
                                                    <button class="btn btn-theme mr-2" type="submit" name="submit"
                                                        value="Enviar">Atualizar dados</button>
                                                    <?php if($_GET["page"] == 'lista-cliente') { ?>
                                                    <button class="btn btn-theme04 ml-2" type="button" onclick="location.href = './'">Cancelar</button>
                                                    <?php } else { ?>
                                                    <button class="btn btn-theme04 ml-2" type="button" onclick="location.href = '../'">Cancelar</button>
                                                    <?php } ?>

                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /col-lg-8 -->
                                </div>
                                <!-- /row -->
                            </div>
                            <!-- /tab-pane -->
                        </div>
                        <!-- /col-lg-12 -->
                    </div>
                    <!-- /row -->
                </div>
            </section>
        </section>
        <!-- /MAIN CONTENT -->
        <!--main content end-->
        <!--footer start-->
        <footer class="site-footer">
            <div class="text-center">
                <p>
                    &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
                </p>
                <div class="credits">

                    Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
                </div>
                <a href="profile.php" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->

    </section>

    <!-- jQuery -->
    <script src="../../../res/lib/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../../../res/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
    <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
    <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="../../../res/lib/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../../res/lib/demo.js"></script>
    <!--common script for all pages-->
    <script src="../../../res/lib/common-scripts.js"></script>

</body>

</html>