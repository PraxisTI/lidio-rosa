<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    var_dump($_POST);
    
    $cnpj = $_POST["cnpj"];
    $cnpj_antigo = $_POST["cnpj_antigo"];
    $fornecedor = $_POST["fornecedor"];
    $empresa = $_POST["empresa"];
    $telefone = $_POST["telefone"];
    $endereco = $_POST["endereco"];

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'UPDATE fornecedores SET cnpj = :cnpj, fornecedor = :fornecedor, empresa = :empresa, telefone = :telefone, endereco = :endereco WHERE cnpj = :cnpj_antigo';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':cnpj', $cnpj);
    $stmt -> bindParam(':fornecedor', $fornecedor);
    $stmt -> bindParam(':empresa', $empresa);
    $stmt -> bindParam(':telefone', $telefone);
    $stmt -> bindParam(':endereco', $endereco);
    $stmt -> bindParam(':cnpj_antigo', $cnpj_antigo);
    if($stmt -> execute()) {
        $_SESSION['msg'] = "<p style='color: green; text-align: center'>Fornecedor atualizado com sucesso!</p>";
    } else {
        $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível atualizar o fornecedor.<br>Tente novamente.</p>";
    }

    header('Location: ./');