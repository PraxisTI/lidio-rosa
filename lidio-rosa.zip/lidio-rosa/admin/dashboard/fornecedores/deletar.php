<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    if(empty($_POST)) {
        header('Location: ./');
    }

    $cnpj = $_GET["cnpj"];

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'UPDATE fornecedores SET ativo = false WHERE cnpj = :cnpj';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':cnpj', $cnpj);
    if($stmt -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Fornecedor excluído com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível excluir o fornecedor.<br>Tente novamente.</p>";
    }

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";
    echo "<script>location.href='./'</script>";