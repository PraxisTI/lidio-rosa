<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = "SELECT * FROM fornecedores WHERE cnpj = :cnpj";
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':cnpj', $_GET["cnpj"]);
    $stmt -> execute();

    $dados = $stmt -> fetch();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>LidioDash</title>

  <!-- Favicons -->
  <link href="../../../res/img/favicon.png" rel="icon">
  <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../../../res/css/style.css" rel="stylesheet">
  <link href="../../../res/css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="../../../res/css/my-style.css">
  
  <script src="../../../res/lib/chart-master/Chart.js"></script>

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>LIDIO<span>DASH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">

          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../index.html">Sair</a></li>
        </ul>
      </div>
    
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
          <h5 class="centered">
            <?php echo $_SESSION["nome"] ?>
          </h5>
          <li class="mt">
            <a href="../">
              <i class="fa fa-dashboard"></i>
              <span>Lista de Contatos</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../painel-de-controle.php">
              <i class="fa fa-desktop"></i>
              <span>Painel de Controle</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../historico">
              <i class="fa fa-history"></i>
            <span>Histórico</span>
            </a>
          </li>
          <li class="sub-menu">
            <a class="active" href="../fornecedores">
              <i class="fa fa-users"></i>
              <span>Fornecedores</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../marcas">
              <i class="fa fa-tags"></i>
              <span>Marcas</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../servicos">
              <i class="fa fa-wrench"></i>
              <span>Serviços</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../estoque">
              <i class="fa fa-cubes"></i>
              <span>Estoque</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../meus-dados">
              <i class="fa fa-user"></i>
              <span>Meus dados</span>
            </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i> Cadastrar Serviços</h3>
        <!-- FORM VALIDATION -->
        <div class="row mt">
          <div class="col-lg-12">
            <h4><i class="fa fa-angle-right"></i> Preencha os campos abaixo</h4>
            <div class="form-panel">
              <div class=" form">
                <form class="cmxform form-horizontal style-form" id="commentForm" method="post" action="edit.php">
                  <input type="hidden" name="cnpj_antigo" value="<?php echo $dados["cnpj"] ?>">
                  <div class="form-group ">
                    <label for="cname" class="control-label col-lg-2">CNPJ</label>
                    <div class="col-lg-10">
                      <input class=" form-control" placeholder="00.000.000/0000-00" id="" name="cnpj" minlength="2" type="text" value="<?php echo $dados["cnpj"] ?>" required />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="cemail" class="control-label col-lg-2">Nome do Fornecedor</label>
                    <div class="col-lg-10">
                      <input class="form-control " placeholder="Fornecedor" id="" type="" name="fornecedor" value="<?php echo $dados["fornecedor"] ?>" required> 
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="cemail" class="control-label col-lg-2">Nome da Empresa</label>
                    <div class="col-lg-10">
                      <input class="form-control " placeholder="Empresa" id="" type="" name="empresa" value="<?php echo $dados["empresa"] ?>" required> 
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="curl" class="control-label col-lg-2">Telefone</label>
                    <div class="col-lg-10">
                      <input type="text" pattern="([\(][0-9]{2}[\)][\ ]?[0-9]{4,5}[\-][0-9]{4})" placeholder="(99) 99999-9999" name="telefone" id="telefone" class="form-control" onkeypress="mask(this, mphone);" onblur="mask(this, mphone);" value="<?php echo $dados["telefone"] ?>">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Endereço Completo</label>
                    <div class="col-lg-10">
                      <input class="form-control" placeholder="Rua, nº, Bairro, Cidade - UF" id="" name="endereco" value="<?php echo $dados["endereco"] ?>" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                      <button class="btn btn-theme" type="submit">Salvar</button>
                      <button class="btn btn-theme04" type="button" onclick="location.href='./'">Cancelar</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
        <!-- /row -->
   
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer" id="footer-cadastro">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
        </p>
        <div class="credits">
         
         Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
        </div>
        <a href="index.php" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../../res/lib/jquery/jquery.min.js"></script>
  <script src="../../../res/lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
  <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../../../res/lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../../../res/lib/common-scripts.js"></script>
  <!--script for this page-->
  <script src="../../../res/lib/sparkline-chart.js"></script>
  <script>
    document.getElementById("tempo").onkeypress = function(e) {
      var chr = String.fromCharCode(e.which);
      if ("1234567890".indexOf(chr) < 0)
        return false;
    }

    document.getElementById("codigo").onkeypress = function(e) {
      var chr = String.fromCharCode(e.which);
      if ("1234567890".indexOf(chr) < 0)
        return false;
    }

    function moeda(a, e, r, t) {
      let n = ""
        , h = j = 0
        , u = tamanho2 = 0
        , l = ajd2 = ""
        , o = window.Event ? t.which : t.keyCode;
      if (13 == o || 8 == o)
          return !0;
      if (n = String.fromCharCode(o),
      -1 == "0123456789".indexOf(n))
          return !1;
      for (u = a.value.length,
      h = 0; h < u && ("0" == a.value.charAt(h) || a.value.charAt(h) == r); h++)
          ;
      for (l = ""; h < u; h++)
          -1 != "0123456789".indexOf(a.value.charAt(h)) && (l += a.value.charAt(h));
      if (l += n,
      0 == (u = l.length) && (a.value = ""),
      1 == u && (a.value = "0" + r + "0" + l),
      2 == u && (a.value = "0" + r + l),
      u > 2) {
          for (ajd2 = "",
          j = 0,
          h = u - 3; h >= 0; h--)
              3 == j && (ajd2 += e,
              j = 0),
              ajd2 += l.charAt(h),
              j++;
          for (a.value = "",
          tamanho2 = ajd2.length,
          h = tamanho2 - 1; h >= 0; h--)
              a.value += ajd2.charAt(h);
          a.value += r + l.substr(u - 2, u)
      }
      return !1
    }

    function mask(o, f) {
      setTimeout(function() {
        var v = mphone(o.value);
        if (v != o.value) {
          o.value = v;
        }
      }, 1);
    }

    function mphone(v) {
      var r = v.replace(/\D/g, "");
      r = r.replace(/^0/, "");
      if (r.length > 10) {
        r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
      } else if (r.length > 5) {
        r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
      } else if (r.length > 2) {
        r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
      } else {
        r = r.replace(/^(\d*)/, "($1");
      }
      return r;
    }
  </script>

</body>

</html>
