<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    var_dump($_POST);

    
    $cnpj = $_POST["cnpj"];
    $fornecedor = $_POST["fornecedor"];
    $empresa = $_POST["empresa"];
    $telefone = $_POST["telefone"];
    $endereco = $_POST["endereco"];

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'INSERT INTO fornecedores(cnpj, fornecedor, empresa, telefone, endereco) VALUES (:cnpj, :fornecedor, :empresa, :telefone, :endereco)';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':cnpj', $cnpj);
    $stmt -> bindParam(':fornecedor', $fornecedor);
    $stmt -> bindParam(':empresa', $empresa);
    $stmt -> bindParam(':telefone', $telefone);
    $stmt -> bindParam(':endereco', $endereco);
    if($stmt -> execute()) {
        $_SESSION['msg'] = "<p style='color: green; text-align: center'>Fornecedor cadastrado com sucesso!</p>";
    } else {
        $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível cadastrar o fornecedor.<br>Tente novamente.</p>";
    }

    header('Location: ./');