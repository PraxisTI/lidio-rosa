<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }
    
    if(empty($_POST)) {
        header('Location: ./');
    }

    $id = $_GET["id"];

    include_once '../../../php/init.php';

    $PDO = db_connect();

    $sql = 'DELETE FROM status WHERE id_manutencao = :id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $id);
    $stmt -> execute();
    
    $PDO2 = db_connect();
    $sql2 = 'DELETE FROM manutencoes WHERE id = :id LIMIT 1';
    $stmt2 = $PDO -> prepare($sql2);
    $stmt2 -> bindParam(':id', $id);
    if($stmt2 -> execute()) {
        $_SESSION["msg"] = "<p style='color: green; text-align: center'>Manutenção excluída com sucesso!</p>";
    } else {
        $_SESSION["msg"] = "<p style='color: red; text-align: center'>Não foi possível excluir a manutenção. Tente novamente.</p>";
    }

    header('Location: ./');