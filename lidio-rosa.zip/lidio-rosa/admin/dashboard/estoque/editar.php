<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = "SELECT e.*, f.fornecedor FROM estoque AS e JOIN fornecedores AS f ON e.fornecedor_id = f.id WHERE e.id = :id";
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $_GET["id"]);
    $stmt -> execute();

    $dados = $stmt -> fetch();

    $PDO = db_connect();
    $sql = 'SELECT id, marca FROM marcas ORDER BY marca ASC';
    $stmt = $PDO -> prepare($sql);
    $stmt -> execute();
    $marcas = $stmt -> fetchAll();
    
    $PDO = db_connect();
    $sql = 'SELECT id, fornecedor FROM fornecedores WHERE ativo = true ORDER BY fornecedor ASC';
    $stmt = $PDO -> prepare($sql);
    $stmt -> execute();

    $fornecedores = "";

    while ($dados_fornecedor = $stmt -> fetch()) {
      $fornecedores .= "['".$dados_fornecedor["fornecedor"]."', "."'".$dados_fornecedor["id"]."'],";
    }
    

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>LidioDash</title>

  <!-- Favicons -->
  <link href="../../../res/img/favicon.png" rel="icon">
  <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../../res/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../../res/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../../../res/css/style.css" rel="stylesheet">
  <link href="../../../res/css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="../../../res/css/my-style.css">
  <link rel="stylesheet" href="../../../res/css/preenchimento-automatico.css">
  
  <script src="../../../res/lib/chart-master/Chart.js"></script>

</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>LIDIO<span>DASH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">

          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../index.html">Sair</a></li>
        </ul>
      </div>
    
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><img src="../../../images/logo.png" class="img-circle" width="80"></p>
          <h5 class="centered">
            <?php echo $_SESSION["nome"] ?>
          </h5>
          <li class="mt">
            <a href="../">
              <i class="fa fa-dashboard"></i>
              <span>Lista de Contatos</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../painel-de-controle.php">
              <i class="fa fa-desktop"></i>
              <span>Painel de Controle</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../historico">
              <i class="fa fa-history"></i>
            <span>Histórico</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../fornecedores">
              <i class="fa fa-users"></i>
              <span>Fornecedores</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../marcas">
              <i class="fa fa-tags"></i>
              <span>Marcas</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../servicos">
              <i class="fa fa-wrench"></i>
              <span>Serviços</span>
            </a>
          </li>
          <li class="sub-menu">
            <a class="active" href="../estoque">
              <i class="fa fa-cubes"></i>
              <span>Estoque</span>
            </a>
          </li>
          <li class="sub-menu">
            <a href="../meus-dados">
              <i class="fa fa-user"></i>
              <span>Meus dados</span>
            </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i> Editar Peça do Estoque</h3>
        <!-- FORM VALIDATION -->
        <div class="row mt">
          <div class="col-lg-12">
            <h4><i class="fa fa-angle-right"></i> Preencha os campos abaixo</h4>
            <div class="form-panel">
              <div class=" form">
              <form class="cmxform form-horizontal style-form" id="commentForm" method="post" action="edit.php">
                  <input type="hidden" id="fornecedor_cnpj" name="fornecedor_cnpj" value="<?php echo $dados["fornecedor_id"]?>">
                  <input type="hidden" name="id" value="<?php echo $dados["id"]?>">
                  <div class="form-group ">
                    <label for="cemail" class="control-label col-lg-2">Código da Peça</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="" type="text" name="id" value="<?php echo $dados["id"]?>" required>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="cemail" class="control-label col-lg-2">Nome da Peça</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="" type="text" name="peca" value="<?php echo $dados["peca"]?>" required>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="curl" class="control-label col-lg-2">Preço de Custo</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="" type="text" value="<?php echo str_replace('.', ',', $dados["preco"])?>" onKeyPress="return(moeda(this,'.',',',event))" name="preco" />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="curl" class="control-label col-lg-2">Percentual de Aumento</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="percentual" value="<?php echo number_format($dados["percentual"], 2, ',', '.') ?>" type="text" name="percentual" />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Unidade de Medida</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="unidade" value="<?php echo $dados["unidade"] ?>" type="text" name="unidade">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="cemail" class="control-label col-lg-2">Código do Fabricante</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="" type="text" name="codigo_fabricante" value="<?php echo $dados["codigo_fabricante"]?>" required>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Fabricante</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="fabricante" value="<?php echo $dados["fabricante"] ?>" type="text" name="fabricante">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Fornecedor</label>
                    <div class="autocomplete col-lg-10">
                      <input class="form-control" id="fornecedor" value="<?php echo $dados['fornecedor'] ?>" type="text" name="fornecedor">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Marca</label>
                    <div class="col-lg-10">
                      <select name="marca" id="marca" class="form-control" required>
                        <option value="">Selecione uma marca</option>
                        <?php for ($i=0; $i < count($marcas); $i++) { ?>
                        <option <?php echo ($dados["marca_id"]==$marcas[$i]["id"])?"selected":"" ?> value="<?php echo $marcas[$i]["id"] ?>"><?php echo $marcas[$i]["marca"] ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Quantidade disponível</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="" name="quantidade" value="<?php echo $dados["quantidade"]?>" required></input>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Quantidade mínima de estoque</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="minimo" value="<?php echo $dados["minimo"]?>" type="text" name="minimo">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Quantidade máxima de estoque</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="maximo" value="<?php echo $dados["maximo"]?>" type="text" name="maximo">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Aplicação 1</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="aplicacao_1" value="<?php echo $dados["aplicacao_1"]?>" type="text" name="aplicacao_1">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Aplicação 2</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="aplicacao_2" value="<?php echo $dados["aplicacao_2"]?>" type="text" name="aplicacao_2">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="ccomment" class="control-label col-lg-2">Aplicação 3</label>
                    <div class="col-lg-10">
                      <input class="form-control" id="aplicacao_3" value="<?php echo $dados["aplicacao_3"]?>" type="text" name="aplicacao_3">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                      <button class="btn btn-theme" type="submit">Salvar</button>
                      <button class="btn btn-theme04" type="button" onclick="location.href='./'">Cancelar</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
        <!-- /row -->
   
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer" id="footer-cadastro">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Lidio Rosa</strong>. Todos os direitos reservados
        </p>
        <div class="credits">
         
         Produzido por <a href="https://www.praxisjr.com.br/">Praxis - Empresa Jr.</a>
        </div>
        <a href="index.php" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../../res/lib/jquery/jquery.min.js"></script>
  <script src="../../../res/lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="../../../res/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../../res/lib/jquery.scrollTo.min.js"></script>
  <script src="../../../res/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="../../../res/lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="../../../res/lib/common-scripts.js"></script>
  <!--script for this page-->
  <script src="../../../res/lib/sparkline-chart.js"></script>
  <script>

    function moeda(a, e, r, t) {
      let n = ""
        , h = j = 0
        , u = tamanho2 = 0
        , l = ajd2 = ""
        , o = window.Event ? t.which : t.keyCode;
      if (13 == o || 8 == o)
          return !0;
      if (n = String.fromCharCode(o),
      -1 == "0123456789".indexOf(n))
          return !1;
      for (u = a.value.length,
      h = 0; h < u && ("0" == a.value.charAt(h) || a.value.charAt(h) == r); h++)
          ;
      for (l = ""; h < u; h++)
          -1 != "0123456789".indexOf(a.value.charAt(h)) && (l += a.value.charAt(h));
      if (l += n,
      0 == (u = l.length) && (a.value = ""),
      1 == u && (a.value = "0" + r + "0" + l),
      2 == u && (a.value = "0" + r + l),
      u > 2) {
          for (ajd2 = "",
          j = 0,
          h = u - 3; h >= 0; h--)
              3 == j && (ajd2 += e,
              j = 0),
              ajd2 += l.charAt(h),
              j++;
          for (a.value = "",
          tamanho2 = ajd2.length,
          h = tamanho2 - 1; h >= 0; h--)
              a.value += ajd2.charAt(h);
          a.value += r + l.substr(u - 2, u)
      }
      return !1
    }

    document.getElementById("percentual").onkeypress = function(e) {
      var chr = String.fromCharCode(e.which);
      if ("1234567890.,".indexOf(chr) < 0)
        return false;
    }
    
  </script>

  <script>
    function autocomplete(inp, arr, type) {
      /*the autocomplete function takes two arguments,
      the text field element and an array of possible autocompleted values:*/
      var currentFocus;
      /*execute a function when someone writes in the text field:*/
      inp.addEventListener("input", function(e) {
          var a, b, i, val = this.value;
          let id = "";
          /*close any already open lists of autocompleted values*/
          closeAllLists();
          if (!val) { return false;}
          currentFocus = -1;
          /*create a DIV element that will contain the items (values):*/
          a = document.createElement("DIV");
          a.setAttribute("id", this.id + "autocomplete-list");
          a.setAttribute("class", "autocomplete-items");
          /*append the DIV element as a child of the autocomplete container:*/
          this.parentNode.appendChild(a);
          /*for each item in the array...*/
          for (i = 0; i < arr.length; i++) {
            id = arr[i][1];
            /*check if the item starts with the same letters as the text field value:*/
            if (arr[i][0].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
              /*create a DIV element for each matching element:*/
              b = document.createElement("DIV");
              /*make the matching letters bold:*/
              b.innerHTML = "<strong>" + arr[i][0].substr(0, val.length) + "</strong>";
              b.innerHTML += arr[i][0].substr(val.length);
              /*insert a input field that will hold the current array item's value:*/
              b.innerHTML += "<input type='hidden' value='" + arr[i][0] + "' id='" + arr[i][1] + "'>";
              /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
                  /*insert the value for the autocomplete text field:*/
                  inp.value = this.getElementsByTagName("input")[0].value;
                  /*close the list of autocompleted values,
                  (or any other open lists of autocompleted values:*/
                  document.querySelector("#fornecedor_cnpj").value = this.querySelector('input').id
                  closeAllLists();
              });
              a.appendChild(b);
            }
          }
      });
      /*execute a function presses a key on the keyboard:*/
      inp.addEventListener("keydown", function(e) {
          var x = document.getElementById(this.id + "autocomplete-list");
          if (x) x = x.getElementsByTagName("div");
          if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
            increase the currentFocus variable:*/
            currentFocus++;
            /*and and make the current item more visible:*/
            addActive(x);
          } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
            decrease the currentFocus variable:*/
            currentFocus--;
            /*and and make the current item more visible:*/
            addActive(x);
          } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if (currentFocus > -1) {
              /*and simulate a click on the "active" item:*/
              if (x) x[currentFocus].click();
            }
          }
      });
      function addActive(x) {
        /*a function to classify an item as "active":*/
        if (!x) return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (currentFocus >= x.length) currentFocus = 0;
        if (currentFocus < 0) currentFocus = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[currentFocus].classList.add("autocomplete-active");
      }
      function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
          x[i].classList.remove("autocomplete-active");
        }
      }
      function closeAllLists(elmnt) {
        /*close all autocomplete lists in the document,
        except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
          if (elmnt != x[i] && elmnt != inp) {
            x[i].parentNode.removeChild(x[i]);
          }
        }
      }
      /*execute a function when someone clicks in the document:*/
      document.addEventListener("click", function (e) {
          closeAllLists(e.target);
      });
    }

    /*An array containing all the country names in the world:*/
    var fornecedores = [<?php echo $fornecedores; ?>]

    /*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
    autocomplete(document.getElementById("fornecedor"), fornecedores, "fornecedores");
  
    function moeda(a, e, r, t) {
      let n = ""
        , h = j = 0
        , u = tamanho2 = 0
        , l = ajd2 = ""
        , o = window.Event ? t.which : t.keyCode;
      if (13 == o || 8 == o)
          return !0;
      if (n = String.fromCharCode(o),
      -1 == "0123456789".indexOf(n))
          return !1;
      for (u = a.value.length,
      h = 0; h < u && ("0" == a.value.charAt(h) || a.value.charAt(h) == r); h++)
          ;
      for (l = ""; h < u; h++)
          -1 != "0123456789".indexOf(a.value.charAt(h)) && (l += a.value.charAt(h));
      if (l += n,
      0 == (u = l.length) && (a.value = ""),
      1 == u && (a.value = "0" + r + "0" + l),
      2 == u && (a.value = "0" + r + l),
      u > 2) {
          for (ajd2 = "",
          j = 0,
          h = u - 3; h >= 0; h--)
              3 == j && (ajd2 += e,
              j = 0),
              ajd2 += l.charAt(h),
              j++;
          for (a.value = "",
          tamanho2 = ajd2.length,
          h = tamanho2 - 1; h >= 0; h--)
              a.value += ajd2.charAt(h);
          a.value += r + l.substr(u - 2, u)
      }
      return !1
    }

  </script>

</body>

</html>
