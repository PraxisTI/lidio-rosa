<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    $id = $_POST["id"];
    $peca = $_POST["peca"];
    $marca = $_POST["marca"];
    $fornecedor_cnpj = $_POST["fornecedor_cnpj"];
    $preco = str_replace(',', '.', $_POST["preco"]);
    $percentual = str_replace(',', '.', $_POST["percentual"]);
    $quantidade = $_POST["quantidade"];
    $preco_final = $preco*(1+$percentual/100);

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'UPDATE estoque SET id=:id, peca=:peca, fornecedor_id=:fornecedor_id, marca_id=:marca_id, preco=:preco, percentual=:percentual, preco_final=:preco_final, quantidade=:quantidade, minimo=:minimo, maximo=:maximo, unidade=:unidade, codigo_fabricante=:codigo_fabricante, fabricante=:fabricante, aplicacao_1=:aplicacao_1, aplicacao_2=:aplicacao_2, aplicacao_3=:aplicacao_3  WHERE id=:id';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':peca', $peca);
    $stmt -> bindParam(':fornecedor_id', $fornecedor_cnpj);
    $stmt -> bindParam(':marca_id', $marca);
    $stmt -> bindParam(':preco', $preco);
    $stmt -> bindParam(':percentual', $percentual);
    $stmt -> bindParam(':preco_final', $preco_final);
    $stmt -> bindParam(':quantidade', $quantidade);
    $stmt -> bindParam(':minimo', $_POST["minimo"]);
    $stmt -> bindParam(':maximo', $_POST["maximo"]);
    $stmt -> bindParam(':unidade', $_POST["unidade"]);
    $stmt -> bindParam(':codigo_fabricante', $_POST["codigo_fabricante"]);
    $stmt -> bindParam(':fabricante', $_POST["fabricante"]);
    $stmt -> bindParam(':aplicacao_1', $_POST["aplicacao_1"]);
    $stmt -> bindParam(':aplicacao_2', $_POST["aplicacao_2"]);
    $stmt -> bindParam(':aplicacao_3', $_POST["aplicacao_3"]);
    $stmt -> bindParam(':id', $id);
    if($stmt -> execute()) {
        $_SESSION['msg'] = "<p style='color: green; text-align: center'>Peça atualizada no estoque com sucesso!</p>";
    } else {
        $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível atualizar a peça.<br>Tente novamente.</p>";
    }

    header('Location: ./');

    