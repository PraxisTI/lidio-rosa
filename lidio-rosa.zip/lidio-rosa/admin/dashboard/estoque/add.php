<?php
    session_start();
    if (!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    $peca = $_POST["peca"];
    $marca = $_POST["marca"];
    $fornecedor_cnpj = $_POST["fornecedor_cnpj"];
    $preco = str_replace(',', '.', $_POST["preco"]);
    $percentual = str_replace(',', '.', $_POST["percentual"]);
    $quantidade = $_POST["quantidade"];
    $preco_final = $preco*(1+$percentual/100);

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = 'INSERT INTO estoque(id, peca, fornecedor_id, marca_id, preco, percentual, preco_final, quantidade, minimo, maximo, unidade, codigo_fabricante, fabricante, aplicacao_1, aplicacao_2, aplicacao_3) VALUES (:id, :peca, :fornecedor_id, :marca, :preco, :percentual, :preco_final, :quantidade, :minimo, :maximo, :unidade, :codigo_fabricante, :fabricante, :aplicacao_1, :aplicacao_2, :aplicacao_3)';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':id', $_POST["id"]);
    $stmt -> bindParam(':peca', $peca);
    $stmt -> bindParam(':fornecedor_id', $fornecedor_cnpj);
    $stmt -> bindParam(':marca', $marca);
    $stmt -> bindParam(':preco', $preco);
    $stmt -> bindParam(':percentual', $percentual);
    $stmt -> bindParam(':preco_final', $preco_final);
    $stmt -> bindParam(':quantidade', $quantidade);
    $stmt -> bindParam(':minimo', $_POST["minimo"]);
    $stmt -> bindParam(':maximo', $_POST["maximo"]);
    $stmt -> bindParam(':unidade', $_POST["unidade"]);
    $stmt -> bindParam(':codigo_fabricante', $_POST["codigo_fabricante"]);
    $stmt -> bindParam(':fabricante', $_POST["fabricante"]);
    $stmt -> bindParam(':aplicacao_1', $_POST["aplicacao_1"]);
    $stmt -> bindParam(':aplicacao_2', $_POST["aplicacao_2"]);
    $stmt -> bindParam(':aplicacao_3', $_POST["aplicacao_3"]);
    if($stmt -> execute()) {
        $_SESSION['msg'] = "<p style='color: green; text-align: center'>Peça cadastrada com sucesso no estoque!</p>";
    } else {
        $_SESSION['msg'] = "<p style='color: red; text-align: center'>Não foi possível cadastrar a peça.<br>Tente novamente.</p>";
    }
    
    echo $_SESSION["msg"];

    header('Location: ./');
