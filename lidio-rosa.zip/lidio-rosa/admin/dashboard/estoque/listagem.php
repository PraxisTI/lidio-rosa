<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    include_once '../../../php/init.php';

    $PDO = db_connect();
    $sql = "SELECT * FROM estoque WHERE ativo = true ORDER BY peca ASC";
    $stmt = $PDO -> prepare($sql);
    $stmt -> execute();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Paulo Macêdo, Nathália Ornelas">
    <meta name="keyword" content="LidioDash, Lidio, Rosa">
    <title>Listagem de Serviços</title>

    <!-- Favicons -->
    <link href="../../../res/img/favicon.png" rel="icon">
    <link href="../../../res/img/apple-touch-icon.png" rel="apple-touch-icon">

    <style>
        * {
            box-sizing: border-box;
            font-family: sans-serif;
            scroll-behavior: smooth;
        }

        .txt-right {
            text-align: right;
        }

        .txt-left {
            text-align: left;
        }

        .container {
            max-width: 1000px;
            max-height: 100vh;
            
            margin: 0 auto;
            padding: 15px 0;
        }

        header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            align-items: center;
        }

        #logo {
            width: 100px;
            height: 50px;
        }

        .end {
            position: fixed;
            bottom: 50px;
            right: 50px;

            background: #FFEE44;
            color: #444;
            font-weight: bolder;
            box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.4);

            text-decoration: none;
            
            border-radius: 50%;
            
            height: 30px;
            width: 30px;

            display: flex;
            justify-content: center;
            align-items: center;
        }

        .end:hover {
            background: #FFEE00;
            color: #222;
        }

        #cabecalho {
            position: sticky;
            position: -webkit-sticky;
            top: 0;
            font-weight: 700;
            align-items: center;
            text-transform: uppercase;
            background: white;
            
            box-shadow: 0 4px 5px -3px #ccc;
            
        }

        .servico-item {
            display: grid;
            grid-template-columns: 1fr 4fr repeat(3, 1fr);
            gap: 20px;
        }

        .preco {
            display: grid;
            grid-template-columns: 1fr 2fr;
            justify-content: end;
        }

        .botoes {
            display: flex;
            justify-content: center;
        }

        #imprimir {
            background-color: #ede165;
            padding: 12px 18px;
            border: none;
            box-shadow: 0 0 8px #ccc;
            cursor: pointer;
            margin: 24px;
            transform: translateX(-50%);
            border-radius: 8px;
            transition: 0.2s;
            border: none;
        }

        #imprimir:hover {
            box-shadow: 0 0 8px #777;
            background-color: #e8d509;
        }

        @media print {
            #imprimir {
                display: none;
            }
            #cabecalho {
                position: relative;
            }
        }
    </style>

</head>
<body>
    <main class="container">
        <header>
            <img id="logo" src="../../../images/logo-black.png" alt="Lidio Rosa">
            <p class="txt-right">Rua Bombeiro Eliezer Alexandrino, no. 96, Av. Jorge Amado - Salvador/BA <br> Tel: (71) 3371-6420</span></p>
        </header>
        <a href="#fim-da-pagina" class="end">
            ↓
        </a>
        <hr>
        <main>
            <div class="servico-box">
                <div id="cabecalho" class="servico-item">
                    <p>Código</p>
                    <p>Peça</p>
                    <p class="txt-right">Preço de custo</p>
                    <p class="txt-right">Percentual de aumento</p>
                    <p class="txt-right">Preço final</p>
                </div>
                <?php while ($dados = $stmt -> fetch()) { 
                    $preco = number_format($dados["preco"], 2, ',', '.');
                    $percentual = number_format($dados["percentual"], 0, '', '');
                    $preco_final = number_format($dados["preco_final"], 2, ',', '.');
                ?>
                <div class="servico-item" id="info">
                    <span><?php echo $dados["id"] ?></span>
                    <span><?php echo $dados["peca"] ?></span>
                    <div class="preco">
                        <span class="txt-right">R$</span>
                        <span class="txt-right"><?php echo $preco ?></span>
                    </div>
                    <span class="txt-right"><?php echo $percentual ?> %</span>
                    <div class="preco">
                        <span class="txt-right">R$</span>
                        <span class="txt-right"><?php echo $preco_final ?></span>
                    </div>
                </div>
                <?php } ?>
            </div>
        </main>
        
        <div class="botoes" id="fim-da-pagina">
            <button id="imprimir" onclick="window.print()">Imprimir</button>
            <button id="imprimir" onclick="location.href = './'">Voltar</button>
        </div>
    </main>
</body>
</html>