<?php
    session_start();
    if(!$_SESSION["auth_admin"]) {
        header('Location: ../../');
    }

    if(empty($_POST)) {
        header('Location: ../../');
    }

    echo "<h2 style='font-family: sans-serif'>Aguarde alguns instantes...</h2>";

    include_once '../../../php/init.php';

    $placa = strtoupper($_POST["placa"]);
    $placas = $_POST["placas"];

    date_default_timezone_set('America/Sao_Paulo');
    $dia = date('Y-m-d');

    $hora = date('H:i');

    if(!strpos($placas, $placa)) {
        $_SESSION["msg"] = "<p style='color: red; text-align: center;'>Placa não encontrada no banco de dados. Digite corretamente.</p>";
        echo "<script>location.href='./'</script>";
    } else {
        for($i = 0; $i < $_POST["peca_count"]; $i++) {
            $id_peca = "id-peca-".($i+1);
            $id_peca = $_POST[$id_peca];
            $qtd_peca = "qtd-".($i+1);
            $qtd_peca = $_POST[$qtd_peca];
            
            $PDO = db_connect();
            $sql = 'SELECT peca, quantidade, minimo FROM estoque WHERE id=:peca_id';
            $stmt = $PDO -> prepare($sql);
            $stmt -> bindParam(':peca_id', $id_peca);
            $stmt -> execute();
            
            $info = $stmt->fetch();
            
            if($info["quantidade"] - $qtd_peca < $info["minimo"]){
                echo '<script type="text/javascript">alert("'.$info['peca'].' alcaçou a quantidade mínima preestabelecida no estoque!\nAtualize o estoque!");</script>';
            }
            
        } 
        
        $PDO = db_connect();
        $sql = 'INSERT INTO manutencoes(placa, quilometragem, titulo_manutencao, descricao, qtd_servicos, qtd_pecas, data_inicio) VALUES (:placa, :quilometragem, :titulo_manutencao, :descricao, :qtd_servicos, :qtd_pecas, :data_inicio)';
        $stmt = $PDO -> prepare($sql);
        $stmt -> bindParam(':placa', $placa);
        $stmt -> bindParam(':quilometragem', $_POST["quilometragem"]);
        $stmt -> bindParam(':titulo_manutencao', $_POST["titulo_manutencao"]);
        $stmt -> bindParam(':descricao', $_POST["descricao"]);
        $stmt -> bindParam(':qtd_servicos', $_POST["serv_count"]);
        $stmt -> bindParam(':qtd_pecas', $_POST["peca_count"]);
        $stmt -> bindParam(':data_inicio', $_POST["data_inicio"]);
        if($stmt -> execute()) {
            $id_mantencao = $PDO->lastInsertId();
            $PDO2 = db_connect();
            $sql2 = 'INSERT INTO status(id_manutencao, etapa, descricao_etapa, hora, dia) VALUES (:id_manutencao, 1, \'Seu veículo foi estacionado na loja\', :hora, :dia);';
            $stmt2 = $PDO2 -> prepare($sql2);
            $stmt2 -> bindParam(':id_manutencao', $id_mantencao);
            $stmt2 -> bindParam(':hora', $_POST["hora"]);
            $stmt2 -> bindParam(':dia', $dia);
            if($stmt2 -> execute()) {
                for($i = 0; $i < $_POST["peca_count"]; $i++) {
                    $id_peca = "id-peca-".($i+1);
                    $id_peca = $_POST[$id_peca];
                    $qtd_peca = "qtd-".($i+1);
                    $qtd_peca = $_POST[$qtd_peca];
                    
                    $PDO = db_connect();
                    $sql = 'INSERT INTO manutencoes_detalhes(manutencao_id, peca_id, quantidade) VALUES (:manutencao_id, :peca_id, :quantidade);UPDATE estoque SET quantidade=quantidade-:quantidade WHERE id=:peca_id AND quantidade > 0';
                    $stmt = $PDO -> prepare($sql);
                    $stmt -> bindParam(':manutencao_id', $id_mantencao);
                    $stmt -> bindParam(':peca_id', $id_peca);
                    $stmt -> bindParam(':quantidade', $qtd_peca);
                    $stmt -> execute();
                }
                for($i = 0; $i < $_POST["serv_count"]; $i++) {
                    $id_serv = "id-serv-".($i+1);
                    $id_serv = $_POST[$id_serv];
                    
                    $PDO = db_connect();
                    $sql = 'INSERT INTO manutencoes_detalhes(manutencao_id, servico_id) VALUES (:manutencao_id, :servico_id);';
                    $stmt = $PDO -> prepare($sql);
                    $stmt -> bindParam(':manutencao_id', $id_mantencao);
                    $stmt -> bindParam(':servico_id', $id_serv);
                    $stmt -> execute();
                }
                $_SESSION["msg"] = "<p style='color: green; text-align: center;'>Manutenção cadastrada com sucesso!</p>";
            } else {
                $_SESSION["msg"] = "<p style='color: red; text-align: center;'>Erro ao cadastrar manutenção cadastro. Tente novamente.</p>";
            }
            
        } else {
            $_SESSION["msg"] = "<p style='color: red; text-align: center;'>Erro ao realizar cadastro. Tente novamente.</p>";
        }
        
        
        unset($_SESSION["msg"]);
        echo "<script>location.href='../relatorio/index.php?manutencao=$id_mantencao'</script>";   
    }