<?php
    // Inicia a sessão
    session_start();
    $_SESSION["auth_admin"] = false;

    // Inclui configurações do banco
    include_once '../php/init.php';

    // Variáveis enviadas pela formulário
    $email = strtolower ($_POST["email"]);
    $senha = $_POST["senha"];
    
    // Busca cadastro no banco de dados
    // Se não encontrar redireciona para página de login
    $PDO = db_connect();
    $sql = 'SELECT * FROM administradores WHERE email = :email AND senha = :senha';
    $stmt = $PDO -> prepare($sql);
    $stmt -> bindParam(':email', $email);
    $stmt -> bindParam(':senha', $senha);
    if($stmt -> execute()) { // Busca realizada com sucesso
        $dados = $stmt -> fetch();
        if(empty($dados)) { // Nenhum registro no banco de dados
            $_SESSION["msg_auth"] = "<p style='color:#dd2f2c; font-size:13px; text-align:center; transform:translateY(-25px);'>Usuário não encontrado</p>";
            header("Location: index.php");
        } else { // Registro encontrado
            $_SESSION["auth_admin"] = true;
            $_SESSION["admin_id"] = $dados["id"];
            $_SESSION["nome"] = $dados["nome"];
            $_SESSION["permissao"] = $dados["permissao"];

            header("Location: dashboard");
        }
    } else {
        $_SESSION["msg_auth"] = "<p style='color:#dd2f2c; font-size:13px; text-align:center; transform:translateY(-20px);'>Usuário não encontrado</p>";
        header("Location: index.php");
    }

    

